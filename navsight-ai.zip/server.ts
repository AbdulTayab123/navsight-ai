import express from "express";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware for parsing JSON with generous payload limits for base64 images
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ limit: "25mb", extended: true }));

// Helper to initialize Gemini client safely
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Route: Status / Health & Configuration check
app.get("/api/health", (_req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status: "ok",
    appName: "NavSight AI",
    aiConfigured: hasKey,
    timestamp: new Date().toISOString(),
  });
});

// Route: Scene Description
app.post("/api/describe-scene", async (req, res) => {
  try {
    const { image, mimeType = "image/jpeg", promptCustom } = req.body;

    if (!image) {
      return res.status(400).json({ error: "Missing image data" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "GEMINI_API_KEY is not configured on the server. Please verify your environment settings.",
        isMissingKey: true,
      });
    }

    // Clean base64 string
    const cleanBase64 = image.replace(/^data:image\/[a-zA-Z+]+;base64,/, "");

    const systemPrompt = `You are NavSight AI, an assistive visual guide designed specifically for blind and low-vision users.
Your goal is to provide reliable, clear, spatial orientation and safety-first descriptions of the user's surroundings.

Rules:
1. Always state immediate obstacles, level changes (stairs/curbs), or potential hazards first.
2. Use clock-face or left/center/right spatial directions (e.g. 'At 2 o'clock approx 3 meters away').
3. Keep the concise summary brief (1 to 2 spoken sentences) so the user gets quick awareness.
4. The detailed description should cover people, objects, ground surface, lighting, and layout.
5. Provide a list of potential hazards (cables, wet floor, steps, glass doors, moving vehicles) or explicitly state 'No immediate hazards detected'.
6. Do NOT fabricate details. If the image is blurry, dark, or unclear, state that honestly.`;

    const userPromptText = promptCustom || "Describe my surroundings clearly for navigation and awareness.";

    const imagePart = {
      inlineData: {
        mimeType,
        data: cleanBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: {
        parts: [
          imagePart,
          { text: userPromptText },
        ],
      },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            concise_summary: {
              type: Type.STRING,
              description: "1-2 sentence immediate audio-ready summary for orientation and safety.",
            },
            detailed_description: {
              type: Type.STRING,
              description: "Comprehensive spatial description of the scene.",
            },
            spatial_layout: {
              type: Type.OBJECT,
              properties: {
                left: { type: Type.STRING, description: "Objects or features on the user's left." },
                center: { type: Type.STRING, description: "Objects or features directly in front." },
                right: { type: Type.STRING, description: "Objects or features on the user's right." },
                ground: { type: Type.STRING, description: "Ground texture, level changes, stairs, or pavement." },
              },
              required: ["left", "center", "right", "ground"],
            },
            hazards_and_obstacles: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of hazards, trip points, or things to watch out for.",
            },
            lighting_condition: {
              type: Type.STRING,
              description: "Lighting and image clarity (e.g., Bright daylight, Dimly lit, Direct glare).",
            },
            suggested_questions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3 concise follow-up questions the user can tap or speak.",
            },
          },
          required: [
            "concise_summary",
            "detailed_description",
            "spatial_layout",
            "hazards_and_obstacles",
            "lighting_condition",
            "suggested_questions",
          ],
        },
      },
    });

    const textOutput = response.text?.trim();
    if (!textOutput) {
      throw new Error("No response generated from Gemini model.");
    }

    const parsed = JSON.parse(textOutput);
    return res.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error("Error in /api/describe-scene:", err);
    return res.status(500).json({
      error: err.message || "Failed to analyze scene.",
      details: err.toString(),
    });
  }
});

// Route: Read Text / OCR
app.post("/api/read-text", async (req, res) => {
  try {
    const { image, mimeType = "image/jpeg" } = req.body;

    if (!image) {
      return res.status(400).json({ error: "Missing image data" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "GEMINI_API_KEY is not configured on the server.",
        isMissingKey: true,
      });
    }

    const cleanBase64 = image.replace(/^data:image\/[a-zA-Z+]+;base64,/, "");

    const systemPrompt = `You are NavSight AI's OCR and Document Reader for blind and low-vision users.
Your task is to transcribe all text found in the image clearly, in natural reading order.
Categorize the document or sign type, extract the headline/title, and highlight critical instructions, warnings, dates, or prices.
If there are no legible words, state clearly that no text was found.`;

    const imagePart = {
      inlineData: {
        mimeType,
        data: cleanBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: {
        parts: [
          imagePart,
          { text: "Extract and read all text in this image accurately." },
        ],
      },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            has_text: {
              type: Type.BOOLEAN,
              description: "Whether legible text is detected.",
            },
            headline: {
              type: Type.STRING,
              description: "The main title, sign header, or key product name.",
            },
            full_text: {
              type: Type.STRING,
              description: "Complete text transcription in natural reading order.",
            },
            text_type: {
              type: Type.STRING,
              description: "Type of text: Sign, Menu, Prescription/Medicine, Food Label, Screen, Notice, Receipt, Document.",
            },
            key_details: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Critical bullet points like expiration dates, dosages, warnings, prices, or hours.",
            },
            legibility: {
              type: Type.STRING,
              description: "Confidence: High, Moderate, Low / Partially Obscured.",
            },
          },
          required: ["has_text", "headline", "full_text", "text_type", "key_details", "legibility"],
        },
      },
    });

    const textOutput = response.text?.trim();
    if (!textOutput) {
      throw new Error("No response generated from OCR model.");
    }

    const parsed = JSON.parse(textOutput);
    return res.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error("Error in /api/read-text:", err);
    return res.status(500).json({
      error: err.message || "Failed to extract text from image.",
    });
  }
});

// Route: Visual Q&A / Ask Follow-Up about current scene
app.post("/api/ask-scene", async (req, res) => {
  try {
    const { image, mimeType = "image/jpeg", question, history = [] } = req.body;

    if (!question) {
      return res.status(400).json({ error: "Missing question" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "GEMINI_API_KEY is not configured on the server.",
        isMissingKey: true,
      });
    }

    const systemPrompt = `You are NavSight AI, an assistive visual guide speaking directly to a blind or low-vision user.
Answer the user's specific question about the provided image directly, concisely, and with precision.
Use clear spatial references (clock positions, left/right, approximate distance in meters or feet).
If the image doesn't clearly show what is asked, answer honestly without guessing.`;

    const parts: any[] = [];
    if (image) {
      const cleanBase64 = image.replace(/^data:image\/[a-zA-Z+]+;base64,/, "");
      parts.push({
        inlineData: {
          mimeType,
          data: cleanBase64,
        },
      });
    }

    let promptContent = question;
    if (history && history.length > 0) {
      const previousTurns = history
        .map((h: { role: string; content: string }) => `${h.role === "user" ? "User" : "Assistant"}: ${h.content}`)
        .join("\n");
      promptContent = `Previous dialogue:\n${previousTurns}\n\nCurrent Question: ${question}`;
    }

    parts.push({ text: promptContent });

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: { parts },
      config: {
        systemInstruction: systemPrompt,
      },
    });

    const answer = response.text?.trim() || "I was unable to find an answer in this scene.";
    return res.json({ success: true, answer });
  } catch (err: any) {
    console.error("Error in /api/ask-scene:", err);
    return res.status(500).json({
      error: err.message || "Failed to process visual question.",
    });
  }
});

// Route: High-Quality Gemini Speech Synthesis (Studio Voice)
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voiceName = "Kore" } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Missing text for speech generation." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "GEMINI_API_KEY is not configured.",
        isMissingKey: true,
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash-lite-tts",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: text.slice(0, 1000), // safe limit for speech chunk
              speechMetadata: {
                style: "Clear, calm, reassuring accessibility narrator",
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio generated by TTS model.");
    }

    return res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: "audio/wav",
    });
  } catch (err: any) {
    console.error("Error in /api/tts:", err);
    return res.status(500).json({
      error: err.message || "TTS generation failed.",
    });
  }
});

// Route: Real Geocoding & Walking Route Assistance via OpenStreetMap / OSRM
app.post("/api/navigation-route", async (req, res) => {
  try {
    const { originLat, originLng, destinationQuery } = req.body;

    if (!originLat || !originLng || !destinationQuery) {
      return res.status(400).json({ error: "Origin coordinates and destination query are required." });
    }

    // Step 1: Geocode destination using OpenStreetMap Nominatim
    const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
      destinationQuery
    )}&limit=1`;

    const geoRes = await fetch(geocodeUrl, {
      headers: {
        "User-Agent": "NavSight-AI-Accessibility-Assistant/1.0",
      },
    });

    if (!geoRes.ok) {
      throw new Error("Could not contact geocoding service.");
    }

    const geoData = await geoRes.json();
    if (!geoData || geoData.length === 0) {
      return res.status(404).json({
        error: `Could not find location matching "${destinationQuery}". Please try a more specific address or place name.`,
      });
    }

    const destLat = parseFloat(geoData[0].lat);
    const destLng = parseFloat(geoData[0].lon);
    const destinationName = geoData[0].display_name;

    // Step 2: Query OSRM public foot router for walking directions
    const osrmUrl = `https://router.project-osrm.org/route/v1/foot/${originLng},${originLat};${destLng},${destLat}?steps=true&geometries=geojson&overview=full`;

    let walkingSteps: any[] = [];
    let distanceMeters = 0;
    let durationSeconds = 0;

    try {
      const osrmRes = await fetch(osrmUrl, {
        headers: { "User-Agent": "NavSight-AI-Accessibility-Assistant/1.0" },
      });
      if (osrmRes.ok) {
        const osrmData = await osrmRes.json();
        if (osrmData.routes && osrmData.routes.length > 0) {
          const route = osrmData.routes[0];
          distanceMeters = Math.round(route.distance);
          durationSeconds = Math.round(route.duration);

          const legSteps = route.legs?.[0]?.steps || [];
          walkingSteps = legSteps.map((s: any, idx: number) => {
            const modifier = s.maneuver?.modifier ? ` (${s.maneuver.modifier})` : "";
            const instruction = s.maneuver?.instruction || `${s.maneuver?.type || "Walk"}${modifier} along ${s.name || "path"}`;
            return {
              stepNumber: idx + 1,
              instruction,
              name: s.name || "Street / Pathway",
              distanceMeters: Math.round(s.distance),
              durationSeconds: Math.round(s.duration),
            };
          });
        }
      }
    } catch (osrmErr) {
      console.warn("OSRM routing non-fatal warning:", osrmErr);
    }

    // Step 3: Compute direct external links for Google Maps walking & Apple Maps & OSM
    const googleMapsWalkingUrl = `https://www.google.com/maps/dir/?api=1&origin=${originLat},${originLng}&destination=${destLat},${destLng}&travelmode=walking`;
    const openStreetMapUrl = `https://www.openstreetmap.org/directions?engine=fossgis_osrm_foot&route=${originLat}%2C${originLng}%3B${destLat}%2C${destLng}`;

    return res.json({
      success: true,
      origin: { lat: originLat, lng: originLng },
      destination: {
        lat: destLat,
        lng: destLng,
        displayName: destinationName,
      },
      distanceMeters,
      durationMinutes: Math.round(durationSeconds / 60),
      steps: walkingSteps,
      externalLinks: {
        googleMapsWalking: googleMapsWalkingUrl,
        openStreetMap: openStreetMapUrl,
      },
      safetyDisclaimer:
        "CRITICAL SAFETY WARNING: This route is generated for informational planning only. It cannot detect dynamic street obstacles, moving vehicles, construction, or surface hazards. Always use your white cane, guide dog, and personal mobility orientation. Never cross roads solely based on app guidance.",
    });
  } catch (err: any) {
    console.error("Error in /api/navigation-route:", err);
    return res.status(500).json({
      error: err.message || "Failed to calculate navigation route.",
    });
  }
});

// Configure Vite middleware in development or serve static in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === "production";

  if (!isProduction) {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NavSight AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
