# NavSight AI — Assistive Vision & Voice Platform for Blind & Low-Vision Users

**NavSight AI** is a real-time multimodal assistive technology application engineered specifically for individuals who are blind, have low vision, or experience visual impairment. Designed with human-centered accessibility, contrast discipline, auditory orientation, and safety protocols at its core.

---

## 🌟 Key Features

### 1. Describe My Surroundings (Multimodal Scene Orientation)
- **Live Camera & Freeze Frame:** Captures video stream snapshots from rear/environment or front lenses.
- **Multimodal AI Analysis:** Powered by Gemini `gemini-3.8-flash` on the server-side, analyzing immediate path clearance, spatial orientation, ground texture, and hazard points.
- **Concise First, Detailed Second:** Delivers an instant audio-ready 1-2 sentence orientation summary first, with optional expandable 4-quadrant layout (Left, Center, Right, Ground).
- **Hazard Warning Pulse:** Highlights trip hazards, downward steps, wet floors, and low obstructions with distinctive auditory chimes.
- **Visual Follow-Up Q&A:** Users can ask follow-up questions about the scene via voice or text.

### 2. Read Text (OCR & Document Reader)
- Transcribes signs, menus, prescriptions, food labels, and transit schedules.
- Extracts headline/title, categorized document type, formatted text, and bulleted critical details (dosages, expiration dates, warnings, prices).
- One-tap Read Aloud, Repeat, and Copy to Clipboard.

### 3. Voice Assistant
- Hands-free microphone input using native browser Speech Recognition with audio waveform visual feedback.
- Accessible typed input fallback when microphone is unavailable or denied.
- Zero-overlap speech synthesis queue management with controls for Pause, Resume, Repeat, and Stop.
- Dynamic speech speed control (0.8x, 1.0x, 1.25x, 1.5x).

### 4. Walking Navigation & Orientation
- **Location on Demand:** Requests GPS coordinates only when navigation is explicitly initiated.
- **Real Routing:** Geocoding via OpenStreetMap Nominatim and turn-by-turn foot routing via Open Source Routing Machine (OSRM).
- **Direct App Export:** One-tap export to Google Maps walking navigation or OpenStreetMap.
- **Strict Safety Distinction:** Displays and speaks explicit warnings that macro route guidance does NOT detect dynamic traffic or road hazards; never cross streets based solely on digital application output.

### 5. Sessions & Privacy Guarantee
- Session history stored purely in-memory during the active browser session.
- No permanent cloud storage of user photos or GPS coordinates.
- Browser permissions dashboard explaining Camera, Microphone, and Geolocation usage.
- One-click history clear.

### 6. Accessibility & Sensory Engineering
- **WCAG AAA Compliance:** High-contrast color palette (deep navy `#070B19`, cyan `#00F2FE`, white surfaces) and dedicated stark Black & Yellow High Contrast Mode.
- **Text Scaling:** Toggleable Normal (100%), Large (118%), and Extra Large (135%).
- **Web Audio API Sound Effects:** Non-speech tactile auditory confirmation for clicks, shutter capture, success chimes, and warning alerts.
- **Screen Reader Support:** ARIA live regions (`aria-live="polite"` and `aria-live="assertive"`).
- **Keyboard Shortcuts:**
  - `Space`: Toggle Read Aloud / Pause
  - `Alt + C`: Describe Surroundings
  - `Alt + T`: Read Text / OCR
  - `Alt + V`: Voice Assistant
  - `Alt + N`: Walking Navigation
  - `Alt + S`: Stop speech immediately
  - `Alt + K`: Toggle High Contrast
  - `Alt + H`: View Keyboard Shortcuts Guide

---

## 🚀 Environment Variables

Copy `.env.example` to `.env`:

```env
# GEMINI_API_KEY: Injected automatically by Google AI Studio
GEMINI_API_KEY="your-gemini-api-key"

# Port (defaults to 3000)
PORT=3000
```

---

## 🛠️ Development & Testing

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start full-stack development server:**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000`.

3. **Run automated verification tests:**
   ```bash
   npm test
   ```

4. **Verify TypeScript & linting:**
   ```bash
   npm run lint
   ```

---

## 🌐 Browser Compatibility

| Feature | Chrome / Edge | Safari / iOS | Firefox |
|---|---|---|---|
| Camera Access (`getUserMedia`) | Full | Full (iOS 14.3+) | Full |
| Speech Synthesis (`speechSynthesis`) | Full | Full | Full |
| Speech Recognition (`webkitSpeechRecognition`) | Full | Full (iOS 14.5+) | Fallback to Typed Input |
| Geolocation | Full | Full | Full |
| Web Audio API | Full | Full | Full |

---

## 📦 Deployment Instructions

### Full-Stack (Cloud Run / Node.js / Docker)
Build the frontend and run the Express backend with server-side Gemini proxy:
```bash
npm run build
npm start
```

### Netlify Deployment
For Netlify deployment:
1. Set Build Command: `npm run build`
2. Set Publish Directory: `dist`
3. Add Netlify Serverless Functions in `netlify/functions` if hosting serverless proxy endpoints, or configure an external proxy backend. Ensure `GEMINI_API_KEY` is configured in **Site Configuration > Environment Variables**.

---

## ⚠️ Assistive Safety Disclaimer
NavSight AI is designed as a perceptual awareness aid. It does **not** replace cane travel, guide dogs, or certified orientation & mobility training. Users must never cross roadways or disregard physical tactile cues based solely on camera scene output.
