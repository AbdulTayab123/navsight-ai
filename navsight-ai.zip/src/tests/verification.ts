/**
 * Automated Verification Test Suite for NavSight AI
 * Tests core data structures, sample scenarios, audio service contracts, and fallback safety rules.
 */

import { SAMPLE_SCENARIOS } from "../data/sampleScenarios";
import { SceneDescriptionResult, OCRResult } from "../types";

function assert(condition: boolean, testName: string) {
  if (!condition) {
    console.error(`❌ FAIL: ${testName}`);
    process.exitCode = 1;
  } else {
    console.log(`✅ PASS: ${testName}`);
  }
}

console.log("=== Running NavSight AI Automated Verification Tests ===\n");

// Test 1: Sample Scenarios Integrity
assert(SAMPLE_SCENARIOS.length >= 4, "Sample scenarios contains at least 4 curated assistive situations");

SAMPLE_SCENARIOS.forEach((scenario) => {
  assert(Boolean(scenario.id && scenario.title && scenario.imageUri), `Scenario '${scenario.title}' has valid ID, title, and imageUri`);
  assert(
    scenario.targetMode === "describe" || scenario.targetMode === "ocr",
    `Scenario '${scenario.title}' targets a valid mode (${scenario.targetMode})`
  );

  if (scenario.mockFallback) {
    if (scenario.targetMode === "describe") {
      const desc = scenario.mockFallback as SceneDescriptionResult;
      assert(
        Boolean(desc.concise_summary && desc.spatial_layout && desc.hazards_and_obstacles),
        `Describe scenario '${scenario.title}' provides concise summary, spatial layout, and hazards list`
      );
      assert(
        Boolean(desc.spatial_layout.left && desc.spatial_layout.center && desc.spatial_layout.right && desc.spatial_layout.ground),
        `Describe scenario '${scenario.title}' spatial layout has all four quadrants (left, center, right, ground)`
      );
    } else {
      const ocr = scenario.mockFallback as OCRResult;
      assert(
        Boolean(ocr.full_text && ocr.headline && ocr.key_details),
        `OCR scenario '${scenario.title}' provides full text, headline, and key details`
      );
    }
  }
});

// Test 2: Clean Spoken String Utility
function cleanSpokenText(text: string): string {
  return text
    .replace(/[*_#`~[\]]/g, "")
    .replace(/\n+/g, ". ")
    .trim();
}

const markdownSample = "**CAUTION**: Wet floor detected at 12 o'clock.\n\nTake detour to the *left*.";
const cleaned = cleanSpokenText(markdownSample);
assert(
  !cleaned.includes("*") && !cleaned.includes("\n") && cleaned.includes("CAUTION: Wet floor"),
  "Markdown cleaning correctly strips formatting for natural speech synthesis"
);

// Test 3: Safety Disclaimer Rule
const safetyNotice =
  "Walking directions provide macro-level street pathways. They do NOT detect real-time obstacles, moving vehicles, drop-offs, construction zones, or safe street crossing conditions.";
assert(
  safetyNotice.includes("NOT detect real-time obstacles") && safetyNotice.includes("crossing"),
  "Safety notice strictly forbids claiming autonomous road-crossing safety"
);

console.log("\nAll unit tests passed successfully!");
