import React from "react";

interface LiveAnnouncerProps {
  message: string;
  assertiveMessage?: string;
}

export const LiveAnnouncer: React.FC<LiveAnnouncerProps> = ({
  message,
  assertiveMessage = "",
}) => {
  return (
    <>
      {/* Polite live region for standard state announcements */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      >
        {message}
      </div>

      {/* Assertive live region for critical hazard warnings */}
      {assertiveMessage && (
        <div
          role="alert"
          aria-live="assertive"
          aria-atomic="true"
          className="sr-only"
        >
          {assertiveMessage}
        </div>
      )}
    </>
  );
};
