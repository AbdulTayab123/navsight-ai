import React, { useState, useEffect } from "react";
import {
  MapPin,
  Navigation,
  Compass,
  AlertTriangle,
  ExternalLink,
  Loader2,
  Volume2,
  ShieldAlert,
  Search,
  CheckCircle,
  Footprints,
} from "lucide-react";
import { NavigationResult } from "../types";
import { speechService } from "../services/speechService";
import { audioFeedback } from "../services/audioFeedback";
import { fetchWalkingRoute } from "../services/geminiClient";

interface NavigationModeProps {
  highContrast?: boolean;
  onAnnounce: (msg: string) => void;
}

export const NavigationMode: React.FC<NavigationModeProps> = ({
  highContrast = false,
  onAnnounce,
}) => {
  const [locationStatus, setLocationStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [destQuery, setDestQuery] = useState<string>("");
  const [isRouting, setIsRouting] = useState<boolean>(false);
  const [routeResult, setRouteResult] = useState<NavigationResult | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);

  // Request browser geolocation ONLY when requested
  const requestCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus("denied");
      setRouteError("Geolocation is not supported by your browser.");
      return;
    }

    setLocationStatus("requesting");
    audioFeedback.playActionPing();
    onAnnounce("Requesting device GPS location permission...");

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCoords({ lat, lng });
        setLocationStatus("granted");
        audioFeedback.playSuccessChime();
        onAnnounce("GPS location acquired.");

        // Lookup approximate street name using reverse geocoding
        try {
          const revRes = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`
          );
          if (revRes.ok) {
            const revData = await revRes.json();
            if (revData && revData.display_name) {
              setAddress(revData.display_name);
            }
          }
        } catch {
          setAddress(`${lat.toFixed(5)}, ${lng.toFixed(5)}`);
        }
      },
      (err) => {
        console.warn("Geolocation error:", err);
        setLocationStatus("denied");
        audioFeedback.playHazardAlert();
        setRouteError(
          err.code === 1
            ? "Location permission was denied. You can still test navigation by providing an address or using demo coordinates."
            : "Could not retrieve GPS position. Please verify device location settings."
        );
        onAnnounce("Location permission was not granted.");
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 10000,
      }
    );
  };

  const handleCalculateRoute = async (destination: string) => {
    if (!destination.trim()) return;

    // If no coordinates yet, use default city center or request location
    let originLat = coords?.lat;
    let originLng = coords?.lng;

    if (!originLat || !originLng) {
      // Default to demo urban coordinate if user hasn't granted GPS
      originLat = 37.7749;
      originLng = -122.4194;
    }

    setIsRouting(true);
    setRouteError(null);
    audioFeedback.playClick();
    onAnnounce(`Searching walking route to ${destination}`);

    try {
      const result = await fetchWalkingRoute(originLat, originLng, destination);
      setRouteResult(result);
      audioFeedback.playSuccessChime();

      const spokenSummary = `Walking route found to ${destination}. Total distance: ${result.distanceMeters} meters, approximately ${result.durationMinutes} minutes. ${result.steps.length} walking turns found.`;
      speechService.speak(spokenSummary);
      onAnnounce(spokenSummary);
    } catch (err: any) {
      console.error(err);
      setRouteError(err.message || "Failed to find route to destination.");
      audioFeedback.playHazardAlert();
    } finally {
      setIsRouting(false);
    }
  };

  const handleReadRouteSteps = () => {
    if (!routeResult) return;
    audioFeedback.playClick();
    const spokenSteps = routeResult.steps
      .map((s) => `Step ${s.stepNumber}: ${s.instruction} for ${s.distanceMeters} meters.`)
      .join(" ");
    speechService.speak(
      `Starting walking instructions. ${spokenSteps}. Reminder: route guidance is advisory. Always use your cane and check for physical road safety.`
    );
  };

  const presetDestinations = [
    "Nearest Pharmacy",
    "Central Transit Station",
    "Public Library",
    "Supermarket",
    "City Hall",
  ];

  return (
    <div className="space-y-4">
      {/* 1. CRITICAL Assistive Safety Disclaimer Notice */}
      <div
        role="alert"
        aria-label="Navigation Safety Disclaimer"
        className={`rounded-3xl p-5 border transition-all ${
          highContrast
            ? "bg-black border-4 border-yellow-400 text-yellow-300"
            : "bg-amber-950/40 border-amber-500/60 text-amber-100 shadow-xl shadow-amber-950/20"
        }`}
      >
        <div className="flex items-start gap-3.5">
          <div className="p-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold flex-shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-white mb-1">
              Important Safety &amp; Orientation Notice
            </h3>
            <p className="text-xs sm:text-sm text-amber-200/90 leading-relaxed font-medium mb-2">
              Walking directions provide macro-level street pathways. They do <strong>NOT</strong> detect real-time obstacles, moving vehicles, drop-offs, construction zones, or safe street crossing conditions.
            </p>
            <p className="text-xs text-amber-300 font-bold">
              ⚠️ Never cross a road based solely on digital application instructions. Always maintain physical cane/guide dog orientation and acoustic traffic listening.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Geolocation Status & Origin Card */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/95 border-cyan-500/30 text-white shadow-xl"
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                Current Position
              </span>
              <h4 className="text-base sm:text-lg font-bold text-white">
                {coords
                  ? "Device Location Connected"
                  : "Location Permission Needed for Live GPS"}
              </h4>
            </div>
          </div>

          <button
            onClick={requestCurrentLocation}
            disabled={locationStatus === "requesting"}
            type="button"
            aria-label="Acquire or refresh current GPS coordinates"
            className={`min-h-[48px] px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              locationStatus === "requesting"
                ? "opacity-50 cursor-wait bg-slate-800 text-slate-400"
                : highContrast
                ? "bg-yellow-400 text-black hover:bg-yellow-300"
                : "bg-cyan-500 text-slate-950 hover:bg-cyan-400"
            }`}
          >
            {locationStatus === "requesting" ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Compass className="w-4 h-4 stroke-[2.5]" />
            )}
            <span>{coords ? "Refresh GPS" : "Locate My Position"}</span>
          </button>
        </div>

        {address ? (
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-200">
            <strong className="text-cyan-400">Current Area:</strong> {address}
          </div>
        ) : coords ? (
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 font-mono">
            Latitude: {coords.lat.toFixed(5)}, Longitude: {coords.lng.toFixed(5)}
          </div>
        ) : (
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400">
            Tap "Locate My Position" above to request browser geolocation permission and establish accurate starting coordinates.
          </div>
        )}
      </div>

      {/* 3. Destination Entry & Route Search */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-slate-800 text-white shadow-xl"
        }`}
      >
        <h4 className="text-base sm:text-lg font-bold text-white mb-2 flex items-center gap-2">
          <Footprints className="w-5 h-5 text-cyan-400" />
          <span>Walking Destination Assistance</span>
        </h4>
        <p className="text-xs sm:text-sm text-slate-400 mb-4 leading-relaxed">
          Enter an address or landmark to calculate public walking route turns with OpenStreetMap and export to external turn-by-turn navigation apps.
        </p>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-2 mb-4">
          {presetDestinations.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => {
                setDestQuery(preset);
                handleCalculateRoute(preset);
              }}
              type="button"
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/20 font-medium transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
            >
              {preset}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleCalculateRoute(destQuery);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={destQuery}
            onChange={(e) => setDestQuery(e.target.value)}
            placeholder="e.g. 500 Market St, or City Pharmacy..."
            disabled={isRouting}
            aria-label="Destination address or place name"
            className={`flex-1 min-h-[48px] px-4 rounded-xl text-sm border font-medium focus:outline-none focus:ring-4 focus:ring-cyan-400 ${
              highContrast
                ? "bg-slate-950 border-yellow-400 text-yellow-100 placeholder-yellow-600"
                : "bg-slate-950 border-slate-700 text-white placeholder-slate-500"
            }`}
          />
          <button
            type="submit"
            disabled={!destQuery.trim() || isRouting}
            aria-label="Calculate walking directions"
            className={`min-h-[48px] px-5 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
              !destQuery.trim() || isRouting
                ? "opacity-50 cursor-not-allowed bg-slate-800 text-slate-500"
                : highContrast
                ? "bg-yellow-400 text-black hover:bg-yellow-300"
                : "bg-cyan-500 text-slate-950 hover:bg-cyan-400"
            }`}
          >
            {isRouting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
            <span>Get Route</span>
          </button>
        </form>

        {routeError && (
          <div
            role="alert"
            className="mt-4 p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-xs sm:text-sm text-rose-200"
          >
            {routeError}
          </div>
        )}
      </div>

      {/* 4. Route Results & Step-by-Step Directions */}
      {routeResult && (
        <div
          className={`rounded-3xl p-5 sm:p-6 border transition-all ${
            highContrast
              ? "bg-black border-yellow-400 text-yellow-300"
              : "bg-slate-900/95 border-cyan-500/40 text-white shadow-2xl"
          }`}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-bold uppercase text-cyan-400 tracking-wider">
                Walking Route Summary
              </span>
              <h3 className="text-lg sm:text-xl font-black text-white">
                {routeResult.destination.displayName}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Distance: <strong className="text-white">{routeResult.distanceMeters} meters</strong> • Estimated Time: <strong className="text-white">{routeResult.durationMinutes} min</strong>
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleReadRouteSteps}
                type="button"
                aria-label="Read all route turns aloud"
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                  highContrast
                    ? "bg-yellow-400 text-black hover:bg-yellow-300"
                    : "bg-cyan-500 text-slate-950 hover:bg-cyan-400"
                }`}
              >
                <Volume2 className="w-4 h-4 stroke-[2.5]" />
                <span>Read Turns</span>
              </button>

              <a
                href={routeResult.externalLinks.googleMapsWalking}
                target="_blank"
                rel="noopener noreferrer"
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                  highContrast
                    ? "bg-slate-900 border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                    : "bg-slate-800 text-cyan-300 hover:bg-slate-700 border border-cyan-500/30"
                }`}
              >
                <ExternalLink className="w-4 h-4" />
                <span>Open Google Maps</span>
              </a>
            </div>
          </div>

          {/* Turn-by-Turn Steps */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Turn-by-turn pedestrian maneuvers:
            </h4>
            {routeResult.steps.length > 0 ? (
              routeResult.steps.map((step) => (
                <div
                  key={step.stepNumber}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-start gap-3"
                >
                  <div className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-extrabold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {step.stepNumber}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white leading-relaxed">
                      {step.instruction}
                    </p>
                    <span className="text-xs text-slate-400">
                      Continue for {step.distanceMeters} meters ({Math.round(step.durationSeconds / 60)} min)
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">
                Direct pedestrian pathway available. Follow street name markers.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
