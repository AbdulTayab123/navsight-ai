import React, { useState } from "react";
import {
  FileText,
  Volume2,
  Copy,
  Check,
  AlertCircle,
  RotateCcw,
  Sparkles,
  Loader2,
  Tag,
  ShieldCheck,
} from "lucide-react";
import { OCRResult } from "../types";
import { speechService } from "../services/speechService";
import { audioFeedback } from "../services/audioFeedback";

interface ReadTextModeProps {
  ocrData: OCRResult | null;
  isLoading: boolean;
  error: string | null;
  onRetry: () => void;
  highContrast?: boolean;
  onAnnounce: (msg: string) => void;
}

export const ReadTextMode: React.FC<ReadTextModeProps> = ({
  ocrData,
  isLoading,
  error,
  onRetry,
  highContrast = false,
  onAnnounce,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  const handleReadAloud = () => {
    if (!ocrData) return;
    audioFeedback.playClick();
    const spoken = `${ocrData.headline ? `${ocrData.headline}. ` : ""}${ocrData.full_text}. ${
      ocrData.key_details && ocrData.key_details.length > 0
        ? `Key points: ${ocrData.key_details.join(". ")}`
        : ""
    }`;
    speechService.speak(spoken);
    onAnnounce("Reading extracted text aloud");
  };

  const handleCopy = () => {
    if (!ocrData) return;
    audioFeedback.playClick();
    const fullContent = `${ocrData.headline ? `${ocrData.headline}\n\n` : ""}${ocrData.full_text}${
      ocrData.key_details && ocrData.key_details.length > 0
        ? `\n\nKey Details:\n${ocrData.key_details.map((d) => `• ${d}`).join("\n")}`
        : ""
    }`;

    navigator.clipboard.writeText(fullContent).then(() => {
      setCopied(true);
      audioFeedback.playSuccessChime();
      onAnnounce("Text copied to clipboard");
      setTimeout(() => setCopied(false), 2500);
    });
  };

  if (isLoading) {
    return (
      <div
        role="status"
        aria-live="polite"
        className={`p-8 rounded-3xl border text-center flex flex-col items-center justify-center min-h-[300px] ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-cyan-500/30 text-white"
        }`}
      >
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center mb-4 animate-pulse">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
        </div>
        <h3 className="text-xl font-bold mb-2 text-white">Extracting &amp; Reading Text...</h3>
        <p className="text-sm text-slate-300 max-w-md leading-relaxed mb-3">
          Gemini OCR is transcribing words, product details, dates, and instructions in reading order.
        </p>
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-semibold">
          <Sparkles className="w-4 h-4" />
          <span>High-precision optical character recognition</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        role="alert"
        className={`p-6 rounded-3xl border ${
          highContrast
            ? "bg-black border-red-500 text-white"
            : "bg-rose-950/40 border-rose-500/40 text-rose-100"
        }`}
      >
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-rose-500 text-slate-950 font-bold">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white mb-1">Text Recognition Error</h3>
            <p className="text-sm text-rose-200/90 leading-relaxed mb-4">{error}</p>
            <button
              onClick={() => {
                audioFeedback.playClick();
                onRetry();
              }}
              type="button"
              className="px-5 py-2.5 rounded-xl font-bold bg-white text-slate-950 hover:bg-slate-200 flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry OCR</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!ocrData) {
    return (
      <div
        className={`p-8 rounded-3xl border text-center ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/60 border-slate-800 text-slate-300"
        }`}
      >
        <FileText className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-white mb-2">Ready to Read Text</h3>
        <p className="text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
          Snap a photo of any sign, document, medicine label, screen, or menu to have all text extracted and read aloud.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* OCR Header Bar */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/95 border-cyan-500/40 shadow-xl shadow-cyan-950/20 text-white"
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5" />
              <span>{ocrData.text_type || "Detected Text"}</span>
            </span>
            <span className="text-xs text-slate-400">
              Legibility: <strong className="text-slate-200">{ocrData.legibility}</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Read Aloud Button */}
            <button
              onClick={handleReadAloud}
              type="button"
              aria-label="Read extracted text aloud"
              className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                highContrast
                  ? "bg-yellow-400 text-black hover:bg-yellow-300"
                  : "bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-md shadow-cyan-500/20"
              }`}
            >
              <Volume2 className="w-4 h-4 stroke-[2.5]" />
              <span>Read Aloud</span>
            </button>

            {/* Copy Button */}
            <button
              onClick={handleCopy}
              type="button"
              aria-label="Copy extracted text to clipboard"
              className={`min-h-[44px] px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                copied
                  ? "bg-emerald-600 text-white"
                  : highContrast
                  ? "bg-slate-900 border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                  : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
              }`}
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? "Copied!" : "Copy Text"}</span>
            </button>
          </div>
        </div>

        {/* Headline */}
        {ocrData.headline && (
          <h3 className="text-xl sm:text-2xl font-black text-cyan-300 mb-4 tracking-tight">
            {ocrData.headline}
          </h3>
        )}

        {/* Full Extracted Text Area */}
        <div
          tabIndex={0}
          aria-label="Full text content"
          className={`p-4 rounded-2xl mb-4 font-mono text-sm sm:text-base leading-relaxed overflow-x-auto whitespace-pre-wrap select-text ${
            highContrast
              ? "bg-slate-950 border-2 border-yellow-400 text-yellow-100"
              : "bg-slate-950/80 border border-slate-800 text-slate-200"
          }`}
        >
          {ocrData.full_text || "No legible words were identified in this image."}
        </div>

        {/* Key Points / Bullet Points (Dosages, Dates, Prices) */}
        {ocrData.key_details && ocrData.key_details.length > 0 && (
          <div className="pt-3 border-t border-slate-800/80">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Key Extracted Points (Dates, Prices, Instructions)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ocrData.key_details.map((detail, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs sm:text-sm text-slate-200 font-medium flex items-start gap-2"
                >
                  <span className="text-cyan-400 font-bold">•</span>
                  <span>{detail}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
