import React from "react";
import { ShieldAlert, CheckCircle, X, AlertTriangle } from "lucide-react";
import { audioFeedback } from "../services/audioFeedback";

interface SafetyDisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  highContrast?: boolean;
}

export const SafetyDisclaimerModal: React.FC<SafetyDisclaimerModalProps> = ({
  isOpen,
  onClose,
  highContrast = false,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="safety-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
    >
      <div
        className={`w-full max-w-xl rounded-3xl p-6 sm:p-7 border shadow-2xl relative max-h-[90vh] overflow-y-auto ${
          highContrast
            ? "bg-black border-4 border-yellow-400 text-yellow-300"
            : "bg-slate-900 border-amber-500/40 text-white"
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <h3 id="safety-title" className="text-xl font-black text-white">
              Assistive Safety &amp; Usage Protocol
            </h3>
          </div>
          <button
            onClick={() => {
              audioFeedback.playClick();
              onClose();
            }}
            type="button"
            aria-label="Close safety protocol guide"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm leading-relaxed text-slate-200">
          <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-100 font-medium">
            <h4 className="font-extrabold text-white text-base mb-1 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <span>Fundamental Safety Rules</span>
            </h4>
            <p>
              NavSight AI is an auxiliary accessibility aide designed to enhance perceptual awareness. It does <strong>not</strong> replace cane navigation, guide dogs, or certified orientation &amp; mobility training.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-white text-sm uppercase tracking-wider mb-1 text-cyan-400">
              1. Street Crossings &amp; Traffic
            </h5>
            <p className="text-slate-300">
              <strong>NEVER step into a roadway or cross a street based solely on camera scene output.</strong> Optical models can experience latency, motion blur, or obstruction by vehicles. Always rely on audible pedestrian crosswalk signals, cane curb detection, and traffic acoustics.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-white text-sm uppercase tracking-wider mb-1 text-cyan-400">
              2. Obstacle &amp; Drop-Off Detection
            </h5>
            <p className="text-slate-300">
              Downstairs steps, curbs, clear glass doors, or low-hanging objects may occasionally be outside the camera lens angle. Continue sweeping your white cane in your standard shoreline technique.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-white text-sm uppercase tracking-wider mb-1 text-cyan-400">
              3. Medicine &amp; Food Reading
            </h5>
            <p className="text-slate-300">
              When reading medication labels or allergy lists, ensure strong lighting without reflections. If text is flagged as "Partially Obscured" or "Low Confidence", verify critical dosages with a sighted caregiver or pharmacist.
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              audioFeedback.playClick();
              onClose();
            }}
            type="button"
            className="px-6 py-2.5 rounded-xl font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400 cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
          >
            I Understand &amp; Agree
          </button>
        </div>
      </div>
    </div>
  );
};
