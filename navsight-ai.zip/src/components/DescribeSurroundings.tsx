import React, { useState } from "react";
import {
  Volume2,
  AlertTriangle,
  Compass,
  HelpCircle,
  Send,
  Loader2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  CheckCircle2,
  Mic,
  RotateCcw,
} from "lucide-react";
import { SceneDescriptionResult } from "../types";
import { speechService } from "../services/speechService";
import { audioFeedback } from "../services/audioFeedback";
import { askSceneQuestion } from "../services/geminiClient";

interface DescribeSurroundingsProps {
  sceneData: SceneDescriptionResult | null;
  isLoading: boolean;
  error: string | null;
  onRetry: () => void;
  activeImage: string | null;
  highContrast?: boolean;
  onAnnounce: (msg: string) => void;
}

export const DescribeSurroundings: React.FC<DescribeSurroundingsProps> = ({
  sceneData,
  isLoading,
  error,
  onRetry,
  activeImage,
  highContrast = false,
  onAnnounce,
}) => {
  const [showDetailed, setShowDetailed] = useState<boolean>(true);
  const [questionInput, setQuestionInput] = useState<string>("");
  const [isAsking, setIsAsking] = useState<boolean>(false);
  const [qaHistory, setQaHistory] = useState<Array<{ question: string; answer: string }>>([]);

  const handleReadSummary = () => {
    if (!sceneData) return;
    audioFeedback.playClick();
    const spoken = `${sceneData.concise_summary}. ${
      sceneData.hazards_and_obstacles && sceneData.hazards_and_obstacles.length > 0
        ? `Hazards detected: ${sceneData.hazards_and_obstacles.join(". ")}`
        : "No immediate hazards detected."
    }`;
    speechService.speak(spoken);
    onAnnounce("Reading concise scene summary");
  };

  const handleReadFull = () => {
    if (!sceneData) return;
    audioFeedback.playClick();
    const spoken = `${sceneData.concise_summary}. Detailed surroundings: ${sceneData.detailed_description}. Left: ${sceneData.spatial_layout.left}. Center: ${sceneData.spatial_layout.center}. Right: ${sceneData.spatial_layout.right}. Ground: ${sceneData.spatial_layout.ground}. Lighting: ${sceneData.lighting_condition}.`;
    speechService.speak(spoken);
    onAnnounce("Reading comprehensive spatial layout");
  };

  const handleAskQuestion = async (q: string) => {
    if (!q.trim() || !activeImage || isAsking) return;
    audioFeedback.playClick();
    setIsAsking(true);
    setQuestionInput("");
    onAnnounce(`Asking: ${q}`);

    try {
      const historyFormatted = qaHistory.flatMap((item) => [
        { role: "user", content: item.question },
        { role: "assistant", content: item.answer },
      ]);

      const answer = await askSceneQuestion(activeImage, q, historyFormatted);
      setQaHistory((prev) => [...prev, { question: q, answer }]);
      audioFeedback.playSuccessChime();
      speechService.speak(answer);
      onAnnounce(`Answer: ${answer}`);
    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || "Could not answer question.";
      audioFeedback.playHazardAlert();
      speechService.speak(`Error answering question: ${errMsg}`);
    } finally {
      setIsAsking(false);
    }
  };

  if (isLoading) {
    return (
      <div
        role="status"
        aria-live="polite"
        className={`p-8 rounded-3xl border text-center flex flex-col items-center justify-center min-h-[300px] ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-cyan-500/30 text-white"
        }`}
      >
        <div className="relative mb-5">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center animate-pulse">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
        </div>
        <h3 className="text-xl font-extrabold mb-2 text-white">Analyzing Surroundings...</h3>
        <p className="text-sm text-slate-300 max-w-md mb-3 leading-relaxed">
          Gemini multimodal model is scanning your scene for immediate obstacles, ground level changes, and spatial orientation.
        </p>
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-semibold">
          <Sparkles className="w-4 h-4" />
          <span>Synthesizing voice summary</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        role="alert"
        className={`p-6 rounded-3xl border ${
          highContrast
            ? "bg-black border-red-500 text-white"
            : "bg-rose-950/40 border-rose-500/40 text-rose-100"
        }`}
      >
        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 rounded-xl bg-rose-500 text-slate-950 font-bold">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white mb-1">Scene Analysis Error</h3>
            <p className="text-sm text-rose-200/90 leading-relaxed mb-4">{error}</p>
            <button
              onClick={() => {
                audioFeedback.playClick();
                onRetry();
              }}
              type="button"
              className="px-5 py-2.5 rounded-xl font-bold bg-white text-slate-950 hover:bg-slate-200 flex items-center gap-2 cursor-pointer focus-visible:ring-4 focus-visible:ring-white"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Analysis</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!sceneData) {
    return (
      <div
        className={`p-8 rounded-3xl border text-center ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/60 border-slate-800 text-slate-300"
        }`}
      >
        <Compass className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-white mb-2">Ready to Describe Your Surroundings</h3>
        <p className="text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
          Snap a photo with the camera viewfinder above, upload an image, or pick a sample scenario to receive an immediate voice overview.
        </p>
      </div>
    );
  }

  const hasHazards = sceneData.hazards_and_obstacles && sceneData.hazards_and_obstacles.length > 0;

  return (
    <div className="space-y-4">
      {/* 1. Concise Summary Box (Primary Spoken Result) */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-gradient-to-br from-slate-900 to-slate-950 border-cyan-500/40 shadow-xl shadow-cyan-950/20 text-white"
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              Immediate Overview
            </span>
            <span className="text-xs text-slate-400">
              {sceneData.sourceType === "sample" ? "Simulated Test" : "Live Capture"} • {sceneData.timestamp}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleReadSummary}
              type="button"
              aria-label="Read concise summary aloud"
              className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                highContrast
                  ? "bg-yellow-400 text-black hover:bg-yellow-300"
                  : "bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-md shadow-cyan-500/20"
              }`}
            >
              <Volume2 className="w-4 h-4 stroke-[2.5]" />
              <span>Read Summary</span>
            </button>
            <button
              onClick={handleReadFull}
              type="button"
              aria-label="Read complete spatial walk-through aloud"
              className={`min-h-[44px] px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                highContrast
                  ? "bg-slate-900 border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                  : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
              }`}
            >
              <span>Full Details</span>
            </button>
          </div>
        </div>

        {/* Primary summary text */}
        <p className="text-lg sm:text-xl font-bold leading-relaxed text-white mb-4">
          {sceneData.concise_summary}
        </p>

        {/* Lighting & Clarity Note */}
        <div className="text-xs text-slate-400 flex items-center gap-2 pt-2 border-t border-slate-800/80">
          <span className="font-semibold text-slate-300">Environment:</span>
          <span>{sceneData.lighting_condition}</span>
        </div>
      </div>

      {/* 2. Hazards and Obstacles Card (Prominent Safety Detection) */}
      <div
        role="region"
        aria-label="Detected Hazards and Obstacles"
        className={`rounded-2xl p-4 sm:p-5 border transition-all ${
          hasHazards
            ? highContrast
              ? "bg-black border-4 border-yellow-400 text-yellow-200"
              : "bg-amber-950/40 border-amber-500/50 text-amber-100 shadow-lg shadow-amber-950/20"
            : highContrast
            ? "bg-black border border-emerald-400 text-emerald-300"
            : "bg-emerald-950/30 border-emerald-500/30 text-emerald-100"
        }`}
      >
        <div className="flex items-center gap-2.5 mb-2">
          {hasHazards ? (
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          ) : (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          )}
          <h4 className="font-extrabold text-base tracking-wide text-white">
            {hasHazards ? "Potential Hazards & Obstacles to Note" : "Path Assessment"}
          </h4>
        </div>

        {hasHazards ? (
          <ul className="space-y-2 mt-2">
            {sceneData.hazards_and_obstacles.map((hazard, idx) => (
              <li
                key={idx}
                className="text-sm font-semibold flex items-start gap-2 leading-relaxed"
              >
                <span className="text-amber-400 font-bold select-none">•</span>
                <span>{hazard}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-emerald-200 leading-relaxed">
            No immediate trip hazards, stairs, or obstacles directly blocking the walking path detected in this frame. Always confirm with your cane or guide dog.
          </p>
        )}
      </div>

      {/* 3. Spatial Layout Quadrants (Left, Center, Right, Ground) */}
      <div
        className={`rounded-2xl p-5 border ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/80 border-slate-800 text-white"
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-bold text-base flex items-center gap-2 text-white">
            <Compass className="w-4 h-4 text-cyan-400" />
            <span>Spatial Orientation by Direction</span>
          </h4>
          <button
            onClick={() => setShowDetailed(!showDetailed)}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            {showDetailed ? (
              <>
                <span>Collapse</span>
                <ChevronUp className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Expand</span>
                <ChevronDown className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {showDetailed && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-xs font-bold uppercase text-cyan-400 tracking-wider block mb-1">
                Left (9 to 11 o'clock)
              </span>
              <p className="text-sm text-slate-200 leading-relaxed">
                {sceneData.spatial_layout.left}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-xs font-bold uppercase text-cyan-400 tracking-wider block mb-1">
                Center Ahead (12 o'clock)
              </span>
              <p className="text-sm text-slate-200 leading-relaxed">
                {sceneData.spatial_layout.center}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-xs font-bold uppercase text-cyan-400 tracking-wider block mb-1">
                Right (1 to 3 o'clock)
              </span>
              <p className="text-sm text-slate-200 leading-relaxed">
                {sceneData.spatial_layout.right}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-xs font-bold uppercase text-amber-400 tracking-wider block mb-1">
                Ground &amp; Surface
              </span>
              <p className="text-sm text-slate-200 leading-relaxed">
                {sceneData.spatial_layout.ground}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 4. Visual Follow-up Q&A Area */}
      <div
        className={`rounded-2xl p-5 border ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-cyan-500/30 text-white"
        }`}
      >
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-5 h-5 text-cyan-400" />
          <h4 className="font-bold text-base text-white">Ask Follow-up Questions About This Scene</h4>
        </div>

        {/* Suggested Quick Questions */}
        {sceneData.suggested_questions && sceneData.suggested_questions.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {sceneData.suggested_questions.map((sq, i) => (
              <button
                key={i}
                onClick={() => handleAskQuestion(sq)}
                type="button"
                disabled={isAsking}
                className="text-xs px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer font-medium text-left focus-visible:ring-4 focus-visible:ring-cyan-400"
              >
                "{sq}"
              </button>
            ))}
          </div>
        )}

        {/* Q&A History */}
        {qaHistory.length > 0 && (
          <div className="space-y-3 mb-4">
            {qaHistory.map((item, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <p className="text-xs font-bold text-cyan-400">Q: {item.question}</p>
                <p className="text-sm text-slate-200 leading-relaxed font-medium">A: {item.answer}</p>
              </div>
            ))}
          </div>
        )}

        {/* Question Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleAskQuestion(questionInput);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={questionInput}
            onChange={(e) => setQuestionInput(e.target.value)}
            placeholder="e.g. Is there a doorway on my right? What color is the sign?"
            disabled={isAsking || !activeImage}
            aria-label="Type a question about the captured scene"
            className={`flex-1 min-h-[48px] px-4 rounded-xl text-sm border font-medium focus:outline-none focus:ring-4 focus:ring-cyan-400 ${
              highContrast
                ? "bg-slate-950 border-yellow-400 text-yellow-100 placeholder-yellow-600"
                : "bg-slate-950 border-slate-700 text-white placeholder-slate-500"
            }`}
          />
          <button
            type="submit"
            disabled={isAsking || !questionInput.trim() || !activeImage}
            aria-label="Submit question about scene"
            className={`min-h-[48px] px-5 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
              !questionInput.trim() || isAsking
                ? "opacity-50 cursor-not-allowed bg-slate-800 text-slate-500"
                : highContrast
                ? "bg-yellow-400 text-black hover:bg-yellow-300"
                : "bg-cyan-500 text-slate-950 hover:bg-cyan-400"
            }`}
          >
            {isAsking ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            <span className="hidden sm:inline">Ask</span>
          </button>
        </form>
      </div>
    </div>
  );
};
