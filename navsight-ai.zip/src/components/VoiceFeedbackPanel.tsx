import React, { useEffect, useState } from "react";
import { Volume2, VolumeX, Play, Pause, RotateCcw, FastForward, Sparkles } from "lucide-react";
import { speechService, SpeechStatus } from "../services/speechService";
import { AudioWaveform } from "./AudioWaveform";
import { audioFeedback } from "../services/audioFeedback";

interface VoiceFeedbackPanelProps {
  onAnnounce?: (msg: string) => void;
  highContrast?: boolean;
}

export const VoiceFeedbackPanel: React.FC<VoiceFeedbackPanelProps> = ({
  highContrast = false,
}) => {
  const [status, setStatus] = useState<SpeechStatus>("idle");
  const [currentText, setCurrentText] = useState<string>("");
  const [rate, setRate] = useState<number>(1.0);

  useEffect(() => {
    const unsub = speechService.subscribe((newStatus, text) => {
      setStatus(newStatus);
      setCurrentText(text);
    });
    setRate(speechService.getRate());
    return unsub;
  }, []);

  const handleTogglePlayPause = () => {
    audioFeedback.playClick();
    if (status === "speaking") {
      speechService.pause();
    } else if (status === "paused") {
      speechService.resume();
    } else if (currentText) {
      speechService.repeat();
    } else {
      speechService.speak("NavSight AI voice assistant is ready. Point your camera at your surroundings or ask a question.");
    }
  };

  const handleRepeat = () => {
    audioFeedback.playClick();
    if (currentText) {
      speechService.repeat();
    } else {
      speechService.speak("No recent announcement to repeat.");
    }
  };

  const handleStop = () => {
    speechService.stop();
  };

  const handleCycleRate = () => {
    audioFeedback.playClick();
    const rates = [0.8, 1.0, 1.25, 1.5];
    const nextIdx = (rates.indexOf(rate) + 1) % rates.length;
    const newRate = rates[nextIdx >= 0 ? nextIdx : 1];
    setRate(newRate);
    speechService.setRate(newRate);
  };

  const isSpeaking = status === "speaking";
  const isPaused = status === "paused";

  return (
    <div
      role="region"
      aria-label="Voice Feedback Control Panel"
      className={`rounded-2xl p-4 sm:p-5 border transition-all ${
        highContrast
          ? "bg-black border-yellow-400 text-yellow-300 shadow-none"
          : "bg-slate-900/90 backdrop-blur-md border-cyan-500/30 shadow-xl shadow-cyan-950/20 text-white"
      }`}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div
            className={`p-2.5 rounded-xl flex items-center justify-center ${
              isSpeaking
                ? highContrast
                  ? "bg-yellow-400 text-black"
                  : "bg-cyan-500 text-slate-950 animate-pulse"
                : highContrast
                ? "bg-slate-900 text-yellow-300 border border-yellow-400"
                : "bg-slate-800 text-cyan-400"
            }`}
            aria-hidden="true"
          >
            {isSpeaking ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Voice Guidance
              </span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                  isSpeaking
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                    : isPaused
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "bg-slate-800 text-slate-400"
                }`}
                role="status"
              >
                {isSpeaking ? "Speaking" : isPaused ? "Paused" : "Ready"}
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
              Audio Feedback & Readout
            </h2>
          </div>
        </div>

        {/* Audio Waveform */}
        <div className="w-full sm:w-44 flex items-center justify-end">
          <AudioWaveform
            isActive={isSpeaking}
            mode={isSpeaking ? "speaking" : "idle"}
            className="w-36 h-8"
          />
        </div>
      </div>

      {/* Transcript Box */}
      <div
        className={`p-3.5 rounded-xl mb-4 min-h-[64px] flex items-center ${
          highContrast
            ? "bg-slate-950 border border-yellow-400/80 text-yellow-100"
            : "bg-slate-950/70 border border-slate-800/80 text-slate-200"
        }`}
      >
        <p className="text-sm sm:text-base leading-relaxed break-words font-medium">
          {currentText || (
            <span className="text-slate-400 italic">
              Awaiting next voice announcement or scene description. Tap "Describe Surroundings" or ask a question.
            </span>
          )}
        </p>
      </div>

      {/* Primary Voice Controls (Large accessible touch targets min 48px) */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        {/* Play / Pause */}
        <button
          onClick={handleTogglePlayPause}
          type="button"
          aria-label={isSpeaking ? "Pause speech playback" : isPaused ? "Resume speech playback" : "Play announcement"}
          className={`flex-1 min-h-[48px] px-4 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 cursor-pointer ${
            highContrast
              ? "bg-yellow-400 text-black hover:bg-yellow-300 active:scale-95"
              : isSpeaking
              ? "bg-cyan-500 text-slate-950 hover:bg-cyan-400 active:scale-95 shadow-lg shadow-cyan-500/25"
              : "bg-slate-800 text-white hover:bg-slate-700 active:scale-95 border border-slate-700"
          }`}
        >
          {isSpeaking ? (
            <>
              <Pause className="w-5 h-5 fill-current" />
              <span>Pause Speech</span>
            </>
          ) : isPaused ? (
            <>
              <Play className="w-5 h-5 fill-current" />
              <span>Resume Speech</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              <span>Read Aloud</span>
            </>
          )}
        </button>

        {/* Repeat */}
        <button
          onClick={handleRepeat}
          type="button"
          aria-label="Repeat last spoken announcement"
          className={`min-h-[48px] px-3.5 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 cursor-pointer ${
            highContrast
              ? "bg-black border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
              : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
          }`}
        >
          <RotateCcw className="w-5 h-5" />
          <span className="hidden sm:inline">Repeat</span>
        </button>

        {/* Stop Audio */}
        <button
          onClick={handleStop}
          type="button"
          aria-label="Stop all speech immediately"
          disabled={status === "idle"}
          className={`min-h-[48px] px-4 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all focus-visible:ring-4 focus-visible:ring-rose-400 cursor-pointer ${
            status === "idle"
              ? "opacity-40 cursor-not-allowed bg-slate-800 text-slate-500 border border-slate-800"
              : highContrast
              ? "bg-red-600 text-white border-2 border-white hover:bg-red-500"
              : "bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30"
          }`}
        >
          <VolumeX className="w-5 h-5" />
          <span>Stop</span>
        </button>

        {/* Speech Rate Button */}
        <button
          onClick={handleCycleRate}
          type="button"
          aria-label={`Speech speed current ${rate} times normal. Tap to cycle speed.`}
          className={`min-h-[48px] px-3.5 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 cursor-pointer ${
            highContrast
              ? "bg-black border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
              : "bg-slate-800 text-cyan-300 hover:bg-slate-700 border border-slate-700"
          }`}
        >
          <FastForward className="w-4 h-4" />
          <span>{rate}x Speed</span>
        </button>
      </div>
    </div>
  );
};
