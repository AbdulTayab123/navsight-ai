import React, { useEffect, useRef } from "react";

interface AudioWaveformProps {
  isActive: boolean;
  mode?: "speaking" | "listening" | "idle";
  barCount?: number;
  className?: string;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  isActive,
  mode = "speaking",
  barCount = 18,
  className = "",
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameId = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const barWidth = width / barCount - 3;

      for (let i = 0; i < barCount; i++) {
        let barHeight = 6;
        if (isActive) {
          // Calculate rhythmic sinusoidal height variation
          const factor = Math.sin(phase + i * 0.45) * 0.5 + 0.5;
          const secondary = Math.cos(phase * 1.5 - i * 0.3) * 0.3;
          barHeight = Math.max(8, (factor + secondary) * (height - 8));
        }

        const x = i * (barWidth + 3);
        const y = (height - barHeight) / 2;

        // Choose color based on mode
        let gradient = ctx.createLinearGradient(x, y, x, y + barHeight);
        if (mode === "listening") {
          // Luminous emerald / cyan for listening
          gradient.addColorStop(0, "#10B981");
          gradient.addColorStop(1, "#06B6D4");
        } else if (mode === "speaking") {
          // Luminous cyan / electric blue for speaking
          gradient.addColorStop(0, "#38BDF8");
          gradient.addColorStop(1, "#0284C7");
        } else {
          gradient.addColorStop(0, "#475569");
          gradient.addColorStop(1, "#334155");
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, 3);
        ctx.fill();
      }

      if (isActive) {
        phase += mode === "listening" ? 0.08 : 0.12;
      }

      animFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
      }
    };
  }, [isActive, mode, barCount]);

  return (
    <div
      className={`relative flex items-center justify-center ${className}`}
      aria-hidden="true"
    >
      <canvas
        ref={canvasRef}
        width={160}
        height={36}
        className="w-full h-full max-h-9"
      />
    </div>
  );
};
