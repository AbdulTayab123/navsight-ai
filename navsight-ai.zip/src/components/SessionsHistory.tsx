import React, { useState, useEffect } from "react";
import {
  History,
  Trash2,
  Volume2,
  ShieldCheck,
  Camera,
  Mic,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Eye,
  RotateCcw,
} from "lucide-react";
import { HistoryItem } from "../types";
import { speechService } from "../services/speechService";
import { audioFeedback } from "../services/audioFeedback";

interface SessionsHistoryProps {
  history: HistoryItem[];
  onClearHistory: () => void;
  highContrast?: boolean;
  onAnnounce: (msg: string) => void;
}

export const SessionsHistory: React.FC<SessionsHistoryProps> = ({
  history,
  onClearHistory,
  highContrast = false,
  onAnnounce,
}) => {
  const [permissions, setPermissions] = useState<{
    camera: string;
    mic: string;
    geo: string;
  }>({
    camera: "prompt",
    mic: "prompt",
    geo: "prompt",
  });

  const checkPermissions = async () => {
    if (!navigator.permissions) return;
    try {
      const cam = await navigator.permissions.query({ name: "camera" as any }).catch(() => null);
      const mic = await navigator.permissions.query({ name: "microphone" as any }).catch(() => null);
      const geo = await navigator.permissions.query({ name: "geolocation" as any }).catch(() => null);

      setPermissions({
        camera: cam?.state || "unknown",
        mic: mic?.state || "unknown",
        geo: geo?.state || "unknown",
      });
    } catch {
      // Permission query not supported on all browsers
    }
  };

  useEffect(() => {
    checkPermissions();
  }, []);

  const handlePlayItem = (item: HistoryItem) => {
    audioFeedback.playClick();
    speechService.speak(`${item.title}. ${item.summary}`);
    onAnnounce(`Replaying ${item.title}`);
  };

  return (
    <div className="space-y-4">
      {/* 1. Privacy & Consent Notice */}
      <div
        role="region"
        aria-label="Privacy & Security Guarantee"
        className={`rounded-3xl p-5 sm:p-6 border transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-cyan-500/30 text-white shadow-xl"
        }`}
      >
        <div className="flex items-start gap-3.5 mb-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white mb-1">
              Privacy &amp; Data Transparency Guarantee
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              NavSight AI processes your camera images and voice queries in-memory. We do <strong>not</strong> permanently store camera footage, audio recordings, or location coordinates. Your session history is stored only temporarily in your browser during this session.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Browser Permissions Status Manager */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-slate-800 text-white"
        }`}
      >
        <h4 className="text-base font-bold text-white mb-3">Browser Permissions Status &amp; Purpose</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Camera */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-cyan-400" />
                <span>Camera</span>
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 font-semibold">
                {permissions.camera}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Captures scene snapshots for orientation and OCR reading. Never records background video without knowledge.
            </p>
          </div>

          {/* Microphone */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1.5">
                <Mic className="w-4 h-4 text-cyan-400" />
                <span>Microphone</span>
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 font-semibold">
                {permissions.mic}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Converts spoken questions to text. Active only when the microphone button is pressed.
            </p>
          </div>

          {/* Geolocation */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span>Geolocation</span>
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 font-semibold">
                {permissions.geo}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Calculates walking routes from your current street position. Never tracks continuous background movement.
            </p>
          </div>
        </div>
      </div>

      {/* 3. Session History List */}
      <div
        className={`rounded-3xl p-5 sm:p-6 border ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-slate-800 text-white"
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h4 className="text-base sm:text-lg font-bold text-white">
              Recent Session Observations ({history.length})
            </h4>
          </div>

          {history.length > 0 && (
            <button
              onClick={() => {
                audioFeedback.playClick();
                if (window.confirm("Are you sure you want to clear your recent session history?")) {
                  onClearHistory();
                  audioFeedback.playSuccessChime();
                  onAnnounce("Session history cleared.");
                }
              }}
              type="button"
              aria-label="Clear all recent session observations"
              className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all ${
                highContrast
                  ? "bg-red-700 text-white hover:bg-red-600"
                  : "bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/40"
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear History</span>
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <div className="p-8 text-center text-slate-400 bg-slate-950/60 rounded-2xl border border-slate-800">
            <p className="text-sm font-medium">No recent observations recorded in this session yet.</p>
            <p className="text-xs text-slate-500 mt-1">
              Scenes you analyze, text you read, or voice assistant queries will appear here.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {history.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                  highContrast
                    ? "bg-slate-950 border-yellow-400 text-yellow-100"
                    : "bg-slate-950/80 border-slate-800 text-slate-200"
                }`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                      {item.type}
                    </span>
                    <span className="text-xs text-slate-400">{item.timestamp}</span>
                  </div>
                  <h5 className="font-bold text-sm text-white mb-1">{item.title}</h5>
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {item.summary}
                  </p>
                </div>

                <button
                  onClick={() => handlePlayItem(item)}
                  type="button"
                  aria-label={`Replay ${item.title}`}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1.5 cursor-pointer flex-shrink-0"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Replay Audio</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
