import React from "react";
import {
  Eye,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Type,
  Keyboard,
  ShieldAlert,
  Sparkles,
  Play,
  RotateCcw,
} from "lucide-react";
import { AccessibilitySettings } from "../types";
import { audioFeedback } from "../services/audioFeedback";

interface HeaderProps {
  settings: AccessibilitySettings;
  onUpdateSettings: (updater: (prev: AccessibilitySettings) => AccessibilitySettings) => void;
  onOpenShortcuts: () => void;
  onOpenSafety: () => void;
  onStartAssistance: () => void;
  onAnnounce: (msg: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  onOpenShortcuts,
  onOpenSafety,
  onStartAssistance,
  onAnnounce,
}) => {
  const toggleContrast = () => {
    audioFeedback.playClick();
    onUpdateSettings((prev) => {
      const next = !prev.highContrast;
      onAnnounce(next ? "High contrast mode enabled." : "High contrast mode disabled.");
      return { ...prev, highContrast: next };
    });
  };

  const cycleTextSize = () => {
    audioFeedback.playClick();
    onUpdateSettings((prev) => {
      const sizes: Array<AccessibilitySettings["textSize"]> = ["normal", "large", "xlarge"];
      const nextIdx = (sizes.indexOf(prev.textSize) + 1) % sizes.length;
      const next = sizes[nextIdx];
      onAnnounce(`Text size adjusted to ${next}.`);
      return { ...prev, textSize: next };
    });
  };

  const toggleSoundFx = () => {
    onUpdateSettings((prev) => {
      const next = !prev.soundEffects;
      audioFeedback.enabled = next;
      if (next) audioFeedback.playClick();
      onAnnounce(next ? "Sound effects enabled." : "Sound effects muted.");
      return { ...prev, soundEffects: next };
    });
  };

  return (
    <header
      role="banner"
      className={`border-b sticky top-0 z-40 backdrop-blur-xl transition-all ${
        settings.highContrast
          ? "bg-black border-yellow-400 text-yellow-300"
          : "bg-slate-950/90 border-slate-800/80 text-white"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4 flex flex-wrap items-center justify-between gap-3">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg transition-transform hover:scale-105 ${
              settings.highContrast
                ? "bg-yellow-400 text-black border-2 border-yellow-300"
                : "bg-gradient-to-tr from-cyan-500 to-teal-400 text-slate-950 shadow-cyan-500/25"
            }`}
            aria-hidden="true"
          >
            <Eye className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-1.5">
                <span>NavSight</span>
                <span className="text-cyan-400 font-extrabold">AI</span>
              </h1>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Assistive Vision
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Intelligent visual guidance and spatial awareness for blind &amp; low-vision users
            </p>
          </div>
        </div>

        {/* Center / Action: Prominent Start Assistance Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onStartAssistance}
            type="button"
            aria-label="Start Assistance: Narrate current scene and speak welcome guidance"
            className={`min-h-[46px] px-4 sm:px-5 py-2.5 rounded-2xl font-black text-sm flex items-center gap-2 cursor-pointer shadow-lg transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 active:scale-95 ${
              settings.highContrast
                ? "bg-yellow-400 text-black hover:bg-yellow-300 border-2 border-white"
                : "bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 hover:brightness-110 shadow-cyan-500/30"
            }`}
          >
            <Play className="w-4 h-4 fill-current stroke-[2.5]" />
            <span>Start Assistance</span>
          </button>
        </div>

        {/* Accessibility Quick Settings Bar */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* High Contrast Mode Toggle */}
          <button
            onClick={toggleContrast}
            type="button"
            aria-label={`Toggle high contrast mode. Currently ${settings.highContrast ? "Enabled" : "Disabled"}. Hotkey: Alt + K.`}
            className={`min-h-[42px] min-w-[42px] p-2 rounded-xl border flex items-center justify-center cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              settings.highContrast
                ? "bg-yellow-400 text-black border-yellow-300 font-bold"
                : "bg-slate-900 text-slate-200 border-slate-700 hover:bg-slate-800"
            }`}
          >
            {settings.highContrast ? <Sun className="w-5 h-5 fill-current" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* Text Size Cycler */}
          <button
            onClick={cycleTextSize}
            type="button"
            aria-label={`Adjust text scale. Current: ${settings.textSize}. Tap to cycle.`}
            className={`min-h-[42px] px-2.5 py-1.5 rounded-xl border flex items-center gap-1 cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              settings.highContrast
                ? "bg-slate-950 border-yellow-400 text-yellow-300 font-bold"
                : "bg-slate-900 text-slate-200 border-slate-700 hover:bg-slate-800"
            }`}
          >
            <Type className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold uppercase">{settings.textSize === "normal" ? "A" : settings.textSize === "large" ? "A+" : "A++"}</span>
          </button>

          {/* Sound FX Audio Toggle */}
          <button
            onClick={toggleSoundFx}
            type="button"
            aria-label={`Auditory feedback sounds ${settings.soundEffects ? "Enabled" : "Muted"}. Tap to toggle.`}
            className={`min-h-[42px] min-w-[42px] p-2 rounded-xl border flex items-center justify-center cursor-pointer transition-all focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              settings.soundEffects
                ? "bg-slate-900 text-cyan-400 border-slate-700 hover:bg-slate-800"
                : "bg-slate-900 text-slate-500 border-slate-700 opacity-60"
            }`}
          >
            {settings.soundEffects ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>

          {/* Keyboard Shortcuts Dialog */}
          <button
            onClick={() => {
              audioFeedback.playClick();
              onOpenShortcuts();
            }}
            type="button"
            aria-label="View keyboard shortcuts guide (Alt + H)"
            className="min-h-[42px] min-w-[42px] p-2 rounded-xl border bg-slate-900 text-slate-200 border-slate-700 hover:bg-slate-800 flex items-center justify-center cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
          >
            <Keyboard className="w-5 h-5" />
          </button>

          {/* Safety Protocols Guide */}
          <button
            onClick={() => {
              audioFeedback.playClick();
              onOpenSafety();
            }}
            type="button"
            aria-label="View essential blind and low-vision safety guidelines"
            className="min-h-[42px] min-w-[42px] p-2 rounded-xl border bg-slate-900 text-amber-400 border-slate-700 hover:bg-slate-800 flex items-center justify-center cursor-pointer focus-visible:ring-4 focus-visible:ring-amber-400"
          >
            <ShieldAlert className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
