import React, { useEffect, useRef, useState } from "react";
import {
  Camera,
  CameraOff,
  SwitchCamera,
  Upload,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Eye,
  Check,
} from "lucide-react";
import { audioFeedback } from "../services/audioFeedback";
import { SAMPLE_SCENARIOS } from "../data/sampleScenarios";
import { SampleScenario } from "../types";

interface CameraViewfinderProps {
  onCaptureImage: (base64Image: string, sourceType: "camera" | "upload" | "sample", scenario?: SampleScenario) => void;
  highContrast?: boolean;
  activeCapturedImage?: string | null;
  onClearCapture?: () => void;
  preferredMode?: "describe" | "ocr";
}

export const CameraViewfinder: React.FC<CameraViewfinderProps> = ({
  onCaptureImage,
  highContrast = false,
  activeCapturedImage = null,
  onClearCapture,
  preferredMode = "describe",
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isStartingCamera, setIsStartingCamera] = useState<boolean>(false);
  const [showSamplePicker, setShowSamplePicker] = useState<boolean>(false);

  // Initialize or restart camera
  const startCamera = async (facing: "environment" | "user" = facingMode) => {
    setIsStartingCamera(true);
    setCameraError(null);

    // Stop prior stream
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
      setStream(null);
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera API is not supported in this browser environment.");
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn("Camera start failed:", err);
      let message = "Unable to access camera.";
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        message = "Camera permission was denied. You can still upload images or choose test scenarios.";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        message = "No camera found on this device. You can upload an image or choose a sample scenario.";
      } else if (err.name === "NotReadableError") {
        message = "Camera is currently in use by another application.";
      }
      setCameraError(message);
    } finally {
      setIsStartingCamera(false);
    }
  };

  useEffect(() => {
    // Only auto-start camera if no captured image is currently active
    if (!activeCapturedImage) {
      startCamera(facingMode);
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [facingMode]);

  const handleFlipCamera = () => {
    audioFeedback.playClick();
    const nextFacing = facingMode === "environment" ? "user" : "environment";
    setFacingMode(nextFacing);
  };

  const handleCaptureSnapshot = () => {
    audioFeedback.playScanCapture();
    const video = videoRef.current;
    if (!video || !stream) {
      setCameraError("Camera stream is not active. Please start camera or upload an image.");
      return;
    }

    const canvas = canvasRef.current || document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL("image/jpeg", 0.9);
    onCaptureImage(base64, "camera");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    audioFeedback.playScanCapture();
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        onCaptureImage(reader.result, "upload");
      }
    };
    reader.readAsDataURL(file);
    // Reset file input so same file can be uploaded again if needed
    e.target.value = "";
  };

  const handleSelectSample = (scenario: SampleScenario) => {
    audioFeedback.playSuccessChime();
    setShowSamplePicker(false);
    onCaptureImage(scenario.imageUri, "sample", scenario);
  };

  return (
    <div
      role="region"
      aria-label="Scene and Camera Viewfinder Area"
      className={`relative rounded-3xl overflow-hidden border transition-all ${
        highContrast
          ? "bg-black border-yellow-400 text-yellow-300"
          : "bg-slate-950 border-slate-800 shadow-2xl"
      }`}
    >
      {/* Top Overlay Badge */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between gap-2 pointer-events-none">
        <div
          className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 backdrop-blur-md pointer-events-auto ${
            activeCapturedImage
              ? "bg-cyan-500/90 text-slate-950 font-extrabold shadow-md"
              : stream
              ? "bg-slate-900/80 text-emerald-400 border border-emerald-500/40"
              : "bg-slate-900/80 text-amber-400 border border-amber-500/40"
          }`}
        >
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              activeCapturedImage
                ? "bg-slate-950 animate-ping"
                : stream
                ? "bg-emerald-400 animate-pulse"
                : "bg-amber-400"
            }`}
          />
          <span>
            {activeCapturedImage
              ? "Scene Captured for Analysis"
              : stream
              ? `Live View (${facingMode === "environment" ? "Back Lens" : "Front Lens"})`
              : "Camera Inactive"}
          </span>
        </div>

        {/* Retake / Live View toggle if image is frozen */}
        {activeCapturedImage && onClearCapture && (
          <button
            onClick={() => {
              audioFeedback.playClick();
              onClearCapture();
              startCamera(facingMode);
            }}
            type="button"
            aria-label="Return to live camera feed"
            className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900/90 hover:bg-slate-800 text-cyan-300 border border-cyan-500/40 backdrop-blur-md pointer-events-auto flex items-center gap-1.5 cursor-pointer shadow-lg focus-visible:ring-4 focus-visible:ring-cyan-400"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retake / Live View</span>
          </button>
        )}
      </div>

      {/* Main View Area */}
      <div className="relative aspect-[4/3] sm:aspect-[16/10] w-full max-h-[460px] bg-slate-950 flex items-center justify-center overflow-hidden">
        {activeCapturedImage ? (
          // Display the captured snapshot
          <div className="relative w-full h-full flex items-center justify-center bg-slate-950">
            <img
              src={activeCapturedImage}
              alt="Frozen scene captured for AI analysis"
              className="w-full h-full object-contain"
            />
            {/* Visual scanline effect */}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-cyan-500/10 via-transparent to-transparent opacity-60" />
          </div>
        ) : stream ? (
          // Display live video feed
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          // Fallback state when camera is inactive or denied
          <div className="p-6 text-center max-w-md mx-auto flex flex-col items-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${
                highContrast
                  ? "bg-yellow-400 text-black"
                  : "bg-slate-800 text-cyan-400 border border-slate-700"
              }`}
            >
              <CameraOff className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Camera Unavailable</h3>
            <p className="text-sm text-slate-400 mb-5 leading-relaxed">
              {cameraError ||
                "Camera access is not active. You can retry permission, upload any image, or select a sample scenario below."}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => startCamera(facingMode)}
                type="button"
                className="px-4 py-2.5 rounded-xl font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400 flex items-center gap-2 cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry Camera</span>
              </button>
              <button
                onClick={() => setShowSamplePicker(true)}
                type="button"
                className="px-4 py-2.5 rounded-xl font-bold bg-slate-800 text-cyan-300 border border-cyan-500/30 hover:bg-slate-700 flex items-center gap-2 cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
              >
                <Sparkles className="w-4 h-4" />
                <span>Choose Sample Scene</span>
              </button>
            </div>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>

      {/* Primary Action Controls Bar */}
      <div
        className={`p-4 sm:p-5 border-t flex flex-wrap items-center justify-between gap-3 ${
          highContrast
            ? "bg-black border-yellow-400"
            : "bg-slate-900/95 border-slate-800"
        }`}
      >
        <div className="flex items-center gap-2">
          {/* Flip camera */}
          <button
            onClick={handleFlipCamera}
            type="button"
            disabled={!stream}
            aria-label="Switch between back and front camera"
            className={`min-h-[48px] px-3.5 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              !stream
                ? "opacity-40 cursor-not-allowed bg-slate-800 text-slate-500"
                : highContrast
                ? "bg-black border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
            }`}
          >
            <SwitchCamera className="w-5 h-5" />
            <span className="hidden sm:inline">Flip Lens</span>
          </button>

          {/* Upload image */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            onClick={() => {
              audioFeedback.playClick();
              fileInputRef.current?.click();
            }}
            type="button"
            aria-label="Upload photo from device files"
            className={`min-h-[48px] px-3.5 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              highContrast
                ? "bg-black border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                : "bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700"
            }`}
          >
            <Upload className="w-5 h-5" />
            <span className="hidden sm:inline">Upload Image</span>
          </button>
        </div>

        {/* Large Prominent Shutter / Capture Button */}
        <div className="flex-1 sm:flex-initial flex justify-center">
          <button
            onClick={handleCaptureSnapshot}
            type="button"
            disabled={!stream}
            aria-label="Capture scene snapshot for AI analysis"
            className={`min-h-[56px] min-w-[200px] px-6 py-3 rounded-2xl font-extrabold text-base sm:text-lg flex items-center justify-center gap-3 transition-all cursor-pointer shadow-xl focus-visible:ring-4 focus-visible:ring-cyan-400 active:scale-95 ${
              !stream
                ? "opacity-50 cursor-not-allowed bg-slate-800 text-slate-500"
                : highContrast
                ? "bg-yellow-400 text-black hover:bg-yellow-300 border-4 border-yellow-500"
                : "bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 hover:brightness-110 shadow-cyan-500/25"
            }`}
          >
            <Camera className="w-6 h-6 stroke-[2.5]" />
            <span>Snap &amp; Analyze</span>
          </button>
        </div>

        {/* Sample Scenarios Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              audioFeedback.playClick();
              setShowSamplePicker(!showSamplePicker);
            }}
            type="button"
            aria-label="Open curated test scenarios for quick testing"
            className={`min-h-[48px] px-3.5 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400 ${
              showSamplePicker
                ? "bg-cyan-500 text-slate-950 font-bold"
                : highContrast
                ? "bg-black border-2 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                : "bg-slate-800 text-cyan-300 hover:bg-slate-700 border border-cyan-500/30"
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span className="hidden sm:inline">Sample Scenes</span>
          </button>
        </div>
      </div>

      {/* Curated Sample Scenarios Modal Drawer */}
      {showSamplePicker && (
        <div
          role="dialog"
          aria-label="Curated accessibility test scenarios"
          className={`p-4 sm:p-5 border-t ${
            highContrast
              ? "bg-black border-yellow-400"
              : "bg-slate-900 border-slate-800 text-white"
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <h4 className="font-bold text-base text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Curated Accessibility Test Scenarios</span>
              </h4>
              <p className="text-xs text-slate-400">
                Notice: These are clearly labelled simulated scenarios for testing assistive features without requiring live camera targets.
              </p>
            </div>
            <button
              onClick={() => setShowSamplePicker(false)}
              className="text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {SAMPLE_SCENARIOS.map((scenario) => (
              <button
                key={scenario.id}
                onClick={() => handleSelectSample(scenario)}
                type="button"
                className={`p-3 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between focus-visible:ring-4 focus-visible:ring-cyan-400 ${
                  highContrast
                    ? "bg-slate-950 border-yellow-400 hover:bg-yellow-950 text-yellow-200"
                    : "bg-slate-800/80 hover:bg-slate-800 border-slate-700 hover:border-cyan-500/50 text-slate-200"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
                      {scenario.targetMode === "describe" ? "Surroundings" : "Text / OCR"}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700 text-slate-300">
                      Example
                    </span>
                  </div>
                  <p className="font-bold text-sm text-white mb-1">{scenario.title}</p>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                    {scenario.description}
                  </p>
                </div>
                <div className="text-xs font-semibold text-cyan-400 flex items-center gap-1 mt-auto">
                  <span>Load this scenario</span>
                  <Check className="w-3.5 h-3.5" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
