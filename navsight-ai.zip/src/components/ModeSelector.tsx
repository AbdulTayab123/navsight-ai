import React from "react";
import {
  Compass,
  FileText,
  Mic,
  MapPin,
  History,
  Camera,
} from "lucide-react";
import { AppMode } from "../types";
import { audioFeedback } from "../services/audioFeedback";

interface ModeSelectorProps {
  activeMode: AppMode;
  onChangeMode: (mode: AppMode) => void;
  highContrast?: boolean;
}

export const ModeSelector: React.FC<ModeSelectorProps> = ({
  activeMode,
  onChangeMode,
  highContrast = false,
}) => {
  const modes: Array<{
    id: AppMode;
    label: string;
    sublabel: string;
    icon: React.ComponentType<{ className?: string }>;
    hotkey: string;
  }> = [
    {
      id: "describe",
      label: "Describe Surroundings",
      sublabel: "Camera & Obstacles",
      icon: Camera,
      hotkey: "Alt+C",
    },
    {
      id: "ocr",
      label: "Read Text",
      sublabel: "Signs, Menus, Labels",
      icon: FileText,
      hotkey: "Alt+T",
    },
    {
      id: "voice",
      label: "Voice Assistant",
      sublabel: "Ask Any Question",
      icon: Mic,
      hotkey: "Alt+V",
    },
    {
      id: "navigate",
      label: "Walking Navigation",
      sublabel: "Routes & Destinations",
      icon: MapPin,
      hotkey: "Alt+N",
    },
    {
      id: "history",
      label: "Sessions & Privacy",
      sublabel: "History & Permissions",
      icon: History,
      hotkey: "",
    },
  ];

  return (
    <nav
      role="navigation"
      aria-label="Assistive Mode Navigation"
      className="w-full"
    >
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3">
        {modes.map((m) => {
          const Icon = m.icon;
          const isActive = activeMode === m.id;

          return (
            <button
              key={m.id}
              onClick={() => {
                audioFeedback.playClick();
                onChangeMode(m.id);
              }}
              type="button"
              role="tab"
              aria-selected={isActive}
              aria-label={`${m.label}. ${m.sublabel}. ${m.hotkey ? `Shortcut: ${m.hotkey}` : ""}`}
              className={`p-3.5 sm:p-4 rounded-2xl text-left border flex flex-col justify-between transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400 min-h-[92px] ${
                isActive
                  ? highContrast
                    ? "bg-yellow-400 text-black border-4 border-white font-extrabold shadow-xl scale-[1.02]"
                    : "bg-gradient-to-br from-cyan-950/80 via-slate-900 to-slate-900 border-cyan-400 text-white shadow-xl shadow-cyan-500/20 scale-[1.02] ring-1 ring-cyan-400/50"
                  : highContrast
                  ? "bg-black border-2 border-yellow-400/60 text-yellow-300 hover:bg-yellow-950/60"
                  : "bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-850 hover:border-slate-700 hover:text-white"
              }`}
            >
              <div className="flex items-center justify-between w-full mb-2">
                <div
                  className={`p-2 rounded-xl flex items-center justify-center ${
                    isActive
                      ? highContrast
                        ? "bg-black text-yellow-300"
                        : "bg-cyan-500 text-slate-950 font-bold"
                      : "bg-slate-800 text-cyan-400"
                  }`}
                  aria-hidden="true"
                >
                  <Icon className="w-5 h-5 stroke-[2.2]" />
                </div>
                {m.hotkey && (
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                      isActive
                        ? highContrast
                          ? "bg-black text-yellow-300"
                          : "bg-cyan-500/30 text-cyan-200"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {m.hotkey}
                  </span>
                )}
              </div>

              <div>
                <span className="font-extrabold text-sm sm:text-base leading-tight block">
                  {m.label}
                </span>
                <span
                  className={`text-xs block mt-0.5 font-medium ${
                    isActive
                      ? highContrast
                        ? "text-black/80"
                        : "text-cyan-300"
                      : "text-slate-400"
                  }`}
                >
                  {m.sublabel}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
