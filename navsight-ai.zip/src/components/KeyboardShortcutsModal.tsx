import React from "react";
import { Keyboard, X } from "lucide-react";
import { audioFeedback } from "../services/audioFeedback";

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  highContrast?: boolean;
}

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose,
  highContrast = false,
}) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: "Space", desc: "Toggle Read Aloud / Pause current speech" },
    { key: "Alt + C", desc: "Open Describe Surroundings & Camera" },
    { key: "Alt + T", desc: "Open Read Text & OCR Reader" },
    { key: "Alt + V", desc: "Activate Voice Assistant Microphone" },
    { key: "Alt + N", desc: "Open Navigation & Orientation" },
    { key: "Alt + S", desc: "Stop all speech immediately" },
    { key: "Alt + K", desc: "Toggle High-Contrast Mode" },
    { key: "Alt + H", desc: "Open this Keyboard Shortcuts Guide" },
    { key: "Escape", desc: "Close any open dialog or modal" },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="shortcuts-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <div
        className={`w-full max-w-lg rounded-3xl p-6 border shadow-2xl relative ${
          highContrast
            ? "bg-black border-4 border-yellow-400 text-yellow-300"
            : "bg-slate-900 border-cyan-500/40 text-white"
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Keyboard className="w-6 h-6 text-cyan-400" />
            <h3 id="shortcuts-title" className="text-xl font-black text-white">
              Accessibility Keyboard Shortcuts
            </h3>
          </div>
          <button
            onClick={() => {
              audioFeedback.playClick();
              onClose();
            }}
            type="button"
            aria-label="Close shortcuts guide"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 mb-4 leading-relaxed">
          Navigate NavSight AI hands-free using these hotkeys from anywhere in the application:
        </p>

        <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
          {shortcuts.map((sc, i) => (
            <div
              key={i}
              className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-3"
            >
              <kbd className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-cyan-300 font-mono text-xs font-bold shadow">
                {sc.key}
              </kbd>
              <span className="text-xs sm:text-sm text-slate-200 font-medium text-right">
                {sc.desc}
              </span>
            </div>
          ))}
        </div>

        <div className="mt-5 pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              audioFeedback.playClick();
              onClose();
            }}
            type="button"
            className="px-5 py-2.5 rounded-xl font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400 cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
