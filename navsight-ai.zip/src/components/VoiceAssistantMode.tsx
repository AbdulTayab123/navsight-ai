import React, { useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  Send,
  Loader2,
  Volume2,
  MessageSquare,
  AlertCircle,
  Sparkles,
  RotateCcw,
} from "lucide-react";
import { speechService } from "../services/speechService";
import { audioFeedback } from "../services/audioFeedback";
import { askSceneQuestion } from "../services/geminiClient";
import { AudioWaveform } from "./AudioWaveform";

interface VoiceAssistantModeProps {
  activeImage: string | null;
  highContrast?: boolean;
  onAnnounce: (msg: string) => void;
  onRequestCapture?: () => void;
}

interface Message {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
}

export const VoiceAssistantMode: React.FC<VoiceAssistantModeProps> = ({
  activeImage,
  highContrast = false,
  onAnnounce,
  onRequestCapture,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "assistant",
      text: "Hello! I am NavSight Voice Assistant. You can speak into your microphone or type any question about your scene or surroundings.",
      timestamp: "Ready",
    },
  ]);
  const [inputText, setInputText] = useState<string>("");
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [speechRecSupported, setSpeechRecSupported] = useState<boolean>(true);
  const [recError, setRecError] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check SpeechRecognition support
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      setSpeechRecSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        setRecError(null);
        audioFeedback.playActionPing();
        onAnnounce("Listening... speak your question now.");
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript;
        if (transcript) {
          audioFeedback.playSuccessChime();
          handleSendMessage(transcript);
        }
      };

      recognition.onerror = (evt: any) => {
        console.warn("Speech recognition error:", evt);
        setIsListening(false);
        if (evt.error === "not-allowed") {
          setRecError("Microphone access was denied. Please allow microphone permissions or use typed input below.");
        } else if (evt.error === "no-speech") {
          setRecError("No speech was detected. Please try tapping the microphone again.");
        } else {
          setRecError(`Voice input error: ${evt.error}. You can use typed input below.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } catch (e) {
      setSpeechRecSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
    };
  }, []);

  const toggleMicListening = () => {
    if (!recognitionRef.current) {
      setRecError("Speech recognition is not supported in this browser. Please use the typed input below.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      audioFeedback.playClick();
    } else {
      // Cancel active speech playback first so mic doesn't capture assistant audio
      speechService.stop();
      setRecError(null);
      try {
        recognitionRef.current.start();
      } catch (err: any) {
        console.warn("Could not start recognition:", err);
      }
    }
  };

  const handleSendMessage = async (textToSend: string) => {
    const q = textToSend.trim();
    if (!q || isProcessing) return;

    audioFeedback.playClick();
    setInputText("");
    setIsProcessing(true);

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    onAnnounce(`You said: ${q}`);

    try {
      const historyFormatted = messages.map((m) => ({
        role: m.sender === "user" ? "user" : "assistant",
        content: m.text,
      }));

      // Send to backend
      const answer = await askSceneQuestion(activeImage || "", q, historyFormatted);

      const assistantMsg: Message = {
        id: `asst-${Date.now()}`,
        sender: "assistant",
        text: answer,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
      audioFeedback.playSuccessChime();

      // Read aloud automatically
      speechService.speak(answer);
      onAnnounce(`Assistant replied: ${answer}`);
    } catch (err: any) {
      const errorText = err.message || "Failed to process voice assistant request.";
      audioFeedback.playHazardAlert();
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: "assistant",
        text: `Error: ${errorText}. Please verify your network or scene capture.`,
        timestamp: "Alert",
      };
      setMessages((prev) => [...prev, errorMsg]);
      speechService.speak(errorMsg.text);
    } finally {
      setIsProcessing(false);
    }
  };

  const quickPrompts = [
    "What is directly in front of me?",
    "Are there any stairs or curbs ahead?",
    "Is the doorway on my left or right?",
    "What color is the main object?",
    "Is the floor clean and clear?",
  ];

  return (
    <div className="space-y-4">
      {/* Voice Assistant Header Card */}
      <div
        className={`rounded-3xl p-6 border text-center relative overflow-hidden transition-all ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/90 border-cyan-500/30 text-white shadow-2xl"
        }`}
      >
        <div className="max-w-md mx-auto flex flex-col items-center">
          {/* Big Accessible Mic Action Button (min 80px) */}
          <div className="relative mb-4">
            {isListening && (
              <span className="absolute -inset-3 rounded-full bg-cyan-400/20 animate-ping pointer-events-none" />
            )}
            <button
              onClick={toggleMicListening}
              type="button"
              disabled={isProcessing}
              aria-label={
                isListening
                  ? "Stop listening"
                  : "Tap to speak question with microphone"
              }
              className={`w-24 h-24 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-2xl focus-visible:ring-4 focus-visible:ring-cyan-400 active:scale-95 ${
                isListening
                  ? highContrast
                    ? "bg-yellow-400 text-black border-4 border-white animate-pulse"
                    : "bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 shadow-cyan-500/40"
                  : highContrast
                  ? "bg-slate-950 border-4 border-yellow-400 text-yellow-300 hover:bg-yellow-950"
                  : "bg-slate-800 text-cyan-400 hover:bg-slate-700 border-2 border-cyan-500/40 shadow-lg shadow-cyan-950/40"
              }`}
            >
              {isListening ? (
                <Mic className="w-10 h-10 animate-bounce" />
              ) : (
                <Mic className="w-10 h-10 stroke-[2.2]" />
              )}
            </button>
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white mb-2">
            {isListening ? "Listening to Your Voice..." : "Voice Assistant"}
          </h3>
          <p className="text-sm text-slate-300 leading-relaxed mb-3">
            {isListening
              ? "Speak naturally. Tap the button again when finished."
              : speechRecSupported
              ? "Tap the microphone to speak, or use the quick queries below."
              : "Microphone speech recognition is not supported in this browser. Use typed input below."}
          </p>

          {/* Active Audio Waveform */}
          <AudioWaveform
            isActive={isListening}
            mode="listening"
            className="w-48 h-8 mb-2"
          />

          {recError && (
            <div
              role="alert"
              className="mt-3 p-3 rounded-xl bg-amber-950/60 border border-amber-500/50 text-xs sm:text-sm text-amber-200 text-left flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <span>{recError}</span>
            </div>
          )}
        </div>
      </div>

      {/* Quick Assistive Voice Prompts */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border ${
          highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-900/80 border-slate-800 text-white"
        }`}
      >
        <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
          Quick Assistive Queries
        </span>
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              type="button"
              disabled={isProcessing}
              className="text-xs sm:text-sm px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/20 font-medium transition-all cursor-pointer focus-visible:ring-4 focus-visible:ring-cyan-400"
            >
              "{prompt}"
            </button>
          ))}
        </div>
      </div>

      {/* Conversation History Log */}
      <div
        role="log"
        aria-label="Conversation log"
        className={`rounded-3xl p-5 border space-y-3.5 max-h-[380px] overflow-y-auto ${
          highContrast
            ? "bg-black border-yellow-400"
            : "bg-slate-900/90 border-slate-800"
        }`}
      >
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${
              m.sender === "user" ? "items-end" : "items-start"
            }`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 text-sm sm:text-base leading-relaxed ${
                m.sender === "user"
                  ? highContrast
                    ? "bg-yellow-400 text-black font-bold"
                    : "bg-cyan-600 text-white shadow-md shadow-cyan-900/20 font-medium"
                  : highContrast
                  ? "bg-slate-950 border-2 border-yellow-400 text-yellow-200"
                  : "bg-slate-800/90 border border-slate-700 text-slate-100"
              }`}
            >
              <div className="flex items-center justify-between gap-4 mb-1 text-[11px] opacity-75 font-semibold">
                <span>{m.sender === "user" ? "You" : "NavSight AI"}</span>
                <span>{m.timestamp}</span>
              </div>
              <p className="font-medium">{m.text}</p>
            </div>

            {m.sender === "assistant" && m.id !== "welcome" && (
              <button
                onClick={() => {
                  audioFeedback.playClick();
                  speechService.speak(m.text);
                }}
                className="text-xs mt-1 text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
                aria-label="Re-read this message aloud"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Repeat</span>
              </button>
            )}
          </div>
        ))}

        {isProcessing && (
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-800/60 text-slate-300">
            <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
            <span className="text-sm font-semibold">Thinking &amp; composing spoken reply...</span>
          </div>
        )}
      </div>

      {/* Typed Input Form Fallback */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputText);
        }}
        className="flex gap-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type any question or instruction here..."
          disabled={isProcessing}
          aria-label="Type your question for the voice assistant"
          className={`flex-1 min-h-[48px] px-4 rounded-xl text-sm border font-medium focus:outline-none focus:ring-4 focus:ring-cyan-400 ${
            highContrast
              ? "bg-black border-yellow-400 text-yellow-100 placeholder-yellow-600"
              : "bg-slate-950 border-slate-700 text-white placeholder-slate-500"
          }`}
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isProcessing}
          aria-label="Send typed question"
          className={`min-h-[48px] px-5 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer transition-all ${
            !inputText.trim() || isProcessing
              ? "opacity-50 cursor-not-allowed bg-slate-800 text-slate-500"
              : highContrast
              ? "bg-yellow-400 text-black hover:bg-yellow-300"
              : "bg-cyan-500 text-slate-950 hover:bg-cyan-400"
          }`}
        >
          {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          <span>Send</span>
        </button>
      </form>
    </div>
  );
};
