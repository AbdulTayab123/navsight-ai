/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  AppMode,
  AccessibilitySettings,
  SceneDescriptionResult,
  OCRResult,
  HistoryItem,
  SampleScenario,
} from "./types";
import { Header } from "./components/Header";
import { ModeSelector } from "./components/ModeSelector";
import { VoiceFeedbackPanel } from "./components/VoiceFeedbackPanel";
import { CameraViewfinder } from "./components/CameraViewfinder";
import { DescribeSurroundings } from "./components/DescribeSurroundings";
import { ReadTextMode } from "./components/ReadTextMode";
import { VoiceAssistantMode } from "./components/VoiceAssistantMode";
import { NavigationMode } from "./components/NavigationMode";
import { SessionsHistory } from "./components/SessionsHistory";
import { KeyboardShortcutsModal } from "./components/KeyboardShortcutsModal";
import { SafetyDisclaimerModal } from "./components/SafetyDisclaimerModal";
import { LiveAnnouncer } from "./components/LiveAnnouncer";
import { speechService } from "./services/speechService";
import { audioFeedback } from "./services/audioFeedback";
import {
  describeScene,
  readTextFromImage,
  checkBackendHealth,
} from "./services/geminiClient";

export default function App() {
  // Navigation mode
  const [activeMode, setActiveMode] = useState<AppMode>("describe");

  // Accessibility settings
  const [settings, setSettings] = useState<AccessibilitySettings>({
    highContrast: false,
    textSize: "normal",
    soundEffects: true,
    speechRate: 1.0,
    useGeminiTTS: false,
    reduceMotion: false,
  });

  // Active scene/image state
  const [activeImage, setActiveImage] = useState<string | null>(null);
  const [sceneData, setSceneData] = useState<SceneDescriptionResult | null>(null);
  const [ocrData, setOcrData] = useState<OCRResult | null>(null);

  // Loading & error states
  const [isAnalyzingScene, setIsAnalyzingScene] = useState<boolean>(false);
  const [isReadingText, setIsReadingText] = useState<boolean>(false);
  const [sceneError, setSceneError] = useState<string | null>(null);
  const [ocrError, setOcrError] = useState<string | null>(null);

  // History state
  const [history, setHistory] = useState<HistoryItem[]>([]);

  // Dialog & Modal states
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);
  const [isSafetyOpen, setIsSafetyOpen] = useState<boolean>(false);

  // Live Screen Reader announcement
  const [liveMsg, setLiveMsg] = useState<string>("NavSight AI assistive vision platform ready.");
  const [assertiveMsg, setAssertiveMsg] = useState<string>("");

  const announce = useCallback((msg: string, isAssertive = false) => {
    if (isAssertive) {
      setAssertiveMsg(msg);
      setTimeout(() => setAssertiveMsg(""), 5000);
    } else {
      setLiveMsg(msg);
    }
  }, []);

  // Health check on mount
  useEffect(() => {
    checkBackendHealth().then((health) => {
      console.log("NavSight AI Backend status:", health);
    });
  }, []);

  // Keyboard shortcuts listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid hotkeys when typing in text fields
      const targetTag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      const isInput = targetTag === "input" || targetTag === "textarea";

      // Space: Toggle play/pause speech (only when not typing in input)
      if (e.code === "Space" && !isInput) {
        e.preventDefault();
        const currentStatus = speechService.getStatus();
        if (currentStatus === "speaking") {
          speechService.pause();
        } else if (currentStatus === "paused") {
          speechService.resume();
        } else {
          speechService.repeat();
        }
        return;
      }

      // Escape: Close dialogs or stop speech
      if (e.key === "Escape") {
        if (isShortcutsOpen || isSafetyOpen) {
          setIsShortcutsOpen(false);
          setIsSafetyOpen(false);
        } else {
          speechService.stop();
        }
        return;
      }

      // Alt key combinations
      if (e.altKey) {
        switch (e.key.toLowerCase()) {
          case "c":
            e.preventDefault();
            audioFeedback.playClick();
            setActiveMode("describe");
            announce("Switched to Describe Surroundings mode.");
            break;
          case "t":
            e.preventDefault();
            audioFeedback.playClick();
            setActiveMode("ocr");
            announce("Switched to Read Text mode.");
            break;
          case "v":
            e.preventDefault();
            audioFeedback.playClick();
            setActiveMode("voice");
            announce("Switched to Voice Assistant mode.");
            break;
          case "n":
            e.preventDefault();
            audioFeedback.playClick();
            setActiveMode("navigate");
            announce("Switched to Walking Navigation mode.");
            break;
          case "s":
            e.preventDefault();
            speechService.stop();
            announce("Speech output stopped.");
            break;
          case "k":
            e.preventDefault();
            audioFeedback.playClick();
            setSettings((prev) => {
              const next = !prev.highContrast;
              announce(next ? "High contrast enabled." : "High contrast disabled.");
              return { ...prev, highContrast: next };
            });
            break;
          case "h":
            e.preventDefault();
            audioFeedback.playClick();
            setIsShortcutsOpen((prev) => !prev);
            break;
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isShortcutsOpen, isSafetyOpen, announce]);

  // Handle scene analysis
  const processSceneAnalysis = async (img: string, scenario?: SampleScenario) => {
    setIsAnalyzingScene(true);
    setSceneError(null);
    announce("Analyzing captured scene with Gemini multimodal model...");

    try {
      const result = await describeScene(img);
      setSceneData(result);
      audioFeedback.playSuccessChime();

      // Speak concise summary immediately
      const spokenText = `${result.concise_summary}. ${
        result.hazards_and_obstacles && result.hazards_and_obstacles.length > 0
          ? `Hazards detected: ${result.hazards_and_obstacles.join(". ")}`
          : "No immediate hazards detected."
      }`;
      speechService.speak(spokenText);
      announce(spokenText);

      // Add to session history
      setHistory((prev) => [
        {
          id: `scene-${Date.now()}`,
          type: "scene",
          title: "Surroundings Description",
          summary: result.concise_summary,
          timestamp: result.timestamp,
          details: result,
          imageThumbnail: img,
        },
        ...prev,
      ]);
    } catch (err: any) {
      console.warn("Scene analysis error:", err);
      // If simulated scenario has mock fallback and API failed or key missing, gracefully use fallback
      if (scenario && scenario.mockFallback) {
        const fallback = scenario.mockFallback as SceneDescriptionResult;
        setSceneData(fallback);
        audioFeedback.playSuccessChime();
        const spokenFallback = `Demonstration scene: ${fallback.concise_summary}`;
        speechService.speak(spokenFallback);
        announce(spokenFallback);

        setHistory((prev) => [
          {
            id: `scene-${Date.now()}`,
            type: "scene",
            title: `Demo: ${scenario.title}`,
            summary: fallback.concise_summary,
            timestamp: fallback.timestamp,
            details: fallback,
            imageThumbnail: img,
          },
          ...prev,
        ]);
      } else {
        const msg = err.message || "Failed to analyze surroundings.";
        setSceneError(msg);
        audioFeedback.playHazardAlert();
        announce(`Error analyzing scene: ${msg}`, true);
      }
    } finally {
      setIsAnalyzingScene(false);
    }
  };

  // Handle OCR text reading
  const processTextReading = async (img: string, scenario?: SampleScenario) => {
    setIsReadingText(true);
    setOcrError(null);
    announce("Extracting text from image...");

    try {
      const result = await readTextFromImage(img);
      setOcrData(result);
      audioFeedback.playSuccessChime();

      const spoken = `${result.headline ? `${result.headline}. ` : ""}${result.full_text}`;
      speechService.speak(spoken);
      announce(spoken);

      setHistory((prev) => [
        {
          id: `ocr-${Date.now()}`,
          type: "ocr",
          title: result.headline || "Extracted Text",
          summary: result.full_text.slice(0, 120),
          timestamp: result.timestamp,
          details: result,
          imageThumbnail: img,
        },
        ...prev,
      ]);
    } catch (err: any) {
      console.warn("OCR error:", err);
      if (scenario && scenario.mockFallback) {
        const fallback = scenario.mockFallback as OCRResult;
        setOcrData(fallback);
        audioFeedback.playSuccessChime();
        const spoken = `${fallback.headline}: ${fallback.full_text}`;
        speechService.speak(spoken);
        announce(spoken);

        setHistory((prev) => [
          {
            id: `ocr-${Date.now()}`,
            type: "ocr",
            title: `Demo OCR: ${scenario.title}`,
            summary: fallback.full_text.slice(0, 120),
            timestamp: fallback.timestamp,
            details: fallback,
            imageThumbnail: img,
          },
          ...prev,
        ]);
      } else {
        const msg = err.message || "Failed to read text from image.";
        setOcrError(msg);
        audioFeedback.playHazardAlert();
        announce(`Error reading text: ${msg}`, true);
      }
    } finally {
      setIsReadingText(false);
    }
  };

  // Callback from CameraViewfinder
  const handleCaptureImage = (
    base64Image: string,
    sourceType: "camera" | "upload" | "sample",
    scenario?: SampleScenario
  ) => {
    setActiveImage(base64Image);

    // If scenario specifies targetMode, automatically switch
    if (scenario && scenario.targetMode && scenario.targetMode !== activeMode) {
      setActiveMode(scenario.targetMode);
    }

    const currentMode = scenario?.targetMode || activeMode;

    if (currentMode === "describe") {
      processSceneAnalysis(base64Image, scenario);
    } else if (currentMode === "ocr") {
      processTextReading(base64Image, scenario);
    } else {
      // In voice mode, capture scene as context
      announce("Scene snapshot captured for voice questions.");
      speechService.speak("Scene snapshot captured. You can now ask questions about this scene.");
    }
  };

  // Prominent "Start Assistance" action
  const handleStartAssistance = () => {
    audioFeedback.playClick();
    setActiveMode("describe");
    const greeting =
      "Welcome to NavSight AI visual assistant. Camera is active. Tap Snap and Analyze to examine what is directly ahead, or press Space to pause speech at any time.";
    speechService.speak(greeting);
    announce(greeting);
  };

  const getTextScaleClass = () => {
    if (settings.textSize === "large") return "text-scale-large";
    if (settings.textSize === "xlarge") return "text-scale-xlarge";
    return "text-scale-normal";
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors duration-200 ${
        settings.highContrast
          ? "app-high-contrast bg-black text-yellow-300"
          : "bg-[#070B19] text-slate-100"
      } ${settings.reduceMotion ? "reduce-motion" : ""} ${getTextScaleClass()}`}
    >
      {/* Hidden ARIA Live Announcer for screen readers */}
      <LiveAnnouncer message={liveMsg} assertiveMessage={assertiveMsg} />

      {/* Header with Accessibility Controls */}
      <Header
        settings={settings}
        onUpdateSettings={setSettings}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onOpenSafety={() => setIsSafetyOpen(true)}
        onStartAssistance={handleStartAssistance}
        onAnnounce={announce}
      />

      {/* Main App Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6 space-y-5">
        {/* Sensory Mode Navigation Tabs */}
        <ModeSelector
          activeMode={activeMode}
          onChangeMode={(mode) => {
            setActiveMode(mode);
            announce(`Switched to ${mode} mode.`);
          }}
          highContrast={settings.highContrast}
        />

        {/* Prominent Voice Feedback Panel */}
        <VoiceFeedbackPanel
          highContrast={settings.highContrast}
          onAnnounce={announce}
        />

        {/* Viewfinder and Mode Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left Column: Camera Viewfinder (Large prominent area) */}
          <div className="lg:col-span-6 space-y-4">
            <CameraViewfinder
              onCaptureImage={handleCaptureImage}
              highContrast={settings.highContrast}
              activeCapturedImage={activeImage}
              onClearCapture={() => {
                setActiveImage(null);
                setSceneData(null);
                setOcrData(null);
                announce("Returned to live camera viewfinder.");
              }}
              preferredMode={activeMode === "ocr" ? "ocr" : "describe"}
            />
          </div>

          {/* Right Column: Mode-Specific Output Panel */}
          <div className="lg:col-span-6">
            {activeMode === "describe" && (
              <DescribeSurroundings
                sceneData={sceneData}
                isLoading={isAnalyzingScene}
                error={sceneError}
                onRetry={() => {
                  if (activeImage) processSceneAnalysis(activeImage);
                }}
                activeImage={activeImage}
                highContrast={settings.highContrast}
                onAnnounce={announce}
              />
            )}

            {activeMode === "ocr" && (
              <ReadTextMode
                ocrData={ocrData}
                isLoading={isReadingText}
                error={ocrError}
                onRetry={() => {
                  if (activeImage) processTextReading(activeImage);
                }}
                highContrast={settings.highContrast}
                onAnnounce={announce}
              />
            )}

            {activeMode === "voice" && (
              <VoiceAssistantMode
                activeImage={activeImage}
                highContrast={settings.highContrast}
                onAnnounce={announce}
              />
            )}

            {activeMode === "navigate" && (
              <NavigationMode
                highContrast={settings.highContrast}
                onAnnounce={announce}
              />
            )}

            {activeMode === "history" && (
              <SessionsHistory
                history={history}
                onClearHistory={() => setHistory([])}
                highContrast={settings.highContrast}
                onAnnounce={announce}
              />
            )}
          </div>
        </div>
      </main>

      {/* Accessible Modals */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
        highContrast={settings.highContrast}
      />

      <SafetyDisclaimerModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
        highContrast={settings.highContrast}
      />

      {/* Footer with Safety Notice */}
      <footer
        role="contentinfo"
        className={`mt-auto border-t py-4 px-4 sm:px-6 text-center text-xs transition-colors ${
          settings.highContrast
            ? "bg-black border-yellow-400 text-yellow-300"
            : "bg-slate-950/80 border-slate-900 text-slate-400"
        }`}
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            <strong>NavSight AI</strong> • Built for independent orientation and tactile awareness. Always use certified mobility aids.
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSafetyOpen(true)}
              className="text-cyan-400 hover:underline cursor-pointer font-semibold"
            >
              Safety Protocols
            </button>
            <button
              onClick={() => setIsShortcutsOpen(true)}
              className="text-cyan-400 hover:underline cursor-pointer font-semibold"
            >
              Keyboard Shortcuts
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
