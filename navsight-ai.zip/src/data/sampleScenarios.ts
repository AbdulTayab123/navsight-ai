import { SampleScenario } from "../types";

// Helper to generate clean, high-contrast SVG data URLs representing realistic scenes
function createSvgDataUrl(title: string, subtitle: string, colors: [string, string, string], objects: string[]): string {
  const [bg1, bg2, accent] = colors;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="480" viewBox="0 0 640 480">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${bg1}" />
        <stop offset="100%" stop-color="${bg2}" />
      </linearGradient>
    </defs>
    <rect width="640" height="480" fill="url(#g)" />
    <!-- Visual Horizon & Ground Line -->
    <rect y="280" width="640" height="200" fill="#0F172A" opacity="0.8" />
    <line x1="0" y1="280" x2="640" y2="280" stroke="${accent}" stroke-width="4" stroke-dasharray="8 8" />
    <!-- Scene Card Overlay -->
    <rect x="40" y="30" width="560" height="120" rx="16" fill="#0A0F1D" fill-opacity="0.9" stroke="${accent}" stroke-width="2" />
    <text x="60" y="75" font-family="system-ui, sans-serif" font-size="24" font-weight="bold" fill="#FFFFFF">${title}</text>
    <text x="60" y="115" font-family="system-ui, sans-serif" font-size="16" fill="${accent}">${subtitle}</text>
    <!-- Graphical Objects -->
    ${objects.join("\n")}
    <rect x="40" y="420" width="560" height="40" rx="8" fill="#000000" opacity="0.6" />
    <text x="60" y="445" font-family="system-ui, sans-serif" font-size="14" fill="#94A3B8">NavSight AI Test Scenario (Simulated Visual Observation)</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export const SAMPLE_SCENARIOS: SampleScenario[] = [
  {
    id: "crosswalk-signal",
    title: "Urban Crosswalk & Pedestrian Signal",
    category: "crosswalk",
    description: "Pedestrian intersection with white zebra stripes, yellow tactile paving curb ramp, and illuminated walk signal.",
    targetMode: "describe",
    imageUri: createSvgDataUrl(
      "Urban Crosswalk & Signal",
      "Pedestrian Curb Ramp with Yellow Tactile Warning Surface",
      ["#1E293B", "#0F172A", "#38BDF8"],
      [
        `<rect x="180" y="300" width="280" height="140" fill="#E2E8F0" />`,
        `<rect x="220" y="300" width="40" height="140" fill="#0F172A" />`,
        `<rect x="300" y="300" width="40" height="140" fill="#0F172A" />`,
        `<rect x="380" y="300" width="40" height="140" fill="#0F172A" />`,
        `<circle cx="520" cy="200" r="32" fill="#22C55E" />`,
        `<text x="500" y="208" font-family="sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">WALK</text>`,
        `<rect x="80" y="260" width="100" height="20" fill="#FACC15" />`,
      ]
    ),
    mockFallback: {
      concise_summary: "You are standing at an urban crosswalk with clear yellow tactile curb paving. The pedestrian signal ahead is illuminated green for WALK.",
      detailed_description: "Directly in front is a zebra-striped pedestrian crosswalk spanning approximately 12 meters across a two-lane asphalt street. On your immediate left is a yellow truncated-dome tactile surface indicating the curb edge. At 1 o'clock, across the road, the pedestrian walk sign is illuminated green. There are no stationary vehicles blocking the zebra crossing.",
      spatial_layout: {
        left: "Curb ramp edge with yellow tactile pavers; metal lamppost at 9 o'clock.",
        center: "Zebra-striped crosswalk extending straight ahead across two lanes.",
        right: "Sidewalk extending around the street corner; mailbox 4 meters away.",
        ground: "Asphalt roadway beginning after a 10cm gentle curb transition.",
      },
      hazards_and_obstacles: [
        "Passing traffic: Although signal shows Walk, verify acoustic traffic cues before stepping into road.",
        "Curb drop-off transition ahead.",
      ],
      lighting_condition: "Bright daylight, clear high-contrast visibility.",
      suggested_questions: [
        "Is there any turning car in the intersection?",
        "How wide is the street to cross?",
        "Is the pedestrian countdown timer visible?",
      ],
      timestamp: "10:30 AM",
      sourceType: "sample",
    },
  },
  {
    id: "hallway-hazard",
    title: "Hallway Obstacle & Wet Floor Cone",
    category: "indoor",
    description: "Indoor office corridor with a bright yellow 'Caution Wet Floor' cone in the central walking path.",
    targetMode: "describe",
    imageUri: createSvgDataUrl(
      "Corridor with Wet Floor Cone",
      "Yellow Caution Pyramid Cone in Center Path",
      ["#1E1E2F", "#0B1120", "#F59E0B"],
      [
        `<polygon points="320,200 270,360 370,360" fill="#FACC15" stroke="#D97706" stroke-width="4" />`,
        `<text x="290" y="290" font-family="sans-serif" font-size="14" font-weight="bold" fill="#000000">CAUTION</text>`,
        `<text x="282" y="315" font-family="sans-serif" font-size="12" font-weight="bold" fill="#B45309">WET FLOOR</text>`,
        `<rect x="100" y="180" width="80" height="180" fill="#334155" />`,
        `<rect x="460" y="160" width="90" height="200" fill="#1E293B" stroke="#38BDF8" stroke-width="2" />`,
      ]
    ),
    mockFallback: {
      concise_summary: "CAUTION: A yellow cone warning of a wet floor is positioned directly in your walking path approximately 2 meters ahead.",
      detailed_description: "The indoor corridor has tiled flooring with slight sheen indicating moisture. Directly center at 12 o'clock, about 2 meters away, is a 60cm high yellow caution cone labeled 'WET FLOOR'. The left wall is clear and straight. On the right at 2 o'clock, an open doorway leads into an adjacent room.",
      spatial_layout: {
        left: "Smooth drywall with a handrail along the left side.",
        center: "Yellow pyramid caution wet floor cone 2 meters directly ahead.",
        right: "Open wooden doorway at 2 o'clock approx 3 meters ahead.",
        ground: "Polished tile floor, damp and potentially slippery near center.",
      },
      hazards_and_obstacles: [
        "Yellow cone obstacle directly in center path at 2 meters.",
        "Slippery wet floor surface around the cone; detour slightly to the left recommended.",
      ],
      lighting_condition: "Well-lit indoor fluorescent lighting.",
      suggested_questions: [
        "Is there enough clearance to walk along the left wall?",
        "Where does the doorway on the right lead?",
        "Is the floor wet past the yellow cone?",
      ],
      timestamp: "11:15 AM",
      sourceType: "sample",
    },
  },
  {
    id: "medicine-bottle",
    title: "Prescription Medicine Bottle & Dosage",
    category: "medicine",
    description: "Amber pharmacy container with white prescription label showing dosage instructions, patient directions, and expiration.",
    targetMode: "ocr",
    imageUri: createSvgDataUrl(
      "Prescription Medicine Bottle",
      "AMOXICILLIN 500MG Capsules - RX Label",
      ["#2A1B0E", "#180F08", "#F97316"],
      [
        `<rect x="220" y="160" width="200" height="240" rx="20" fill="#D97706" opacity="0.85" />`,
        `<rect x="235" y="190" width="170" height="180" rx="6" fill="#FFFFFF" />`,
        `<text x="250" y="220" font-family="sans-serif" font-size="14" font-weight="bold" fill="#000000">AMOXICILLIN 500 MG</text>`,
        `<text x="250" y="245" font-family="sans-serif" font-size="11" fill="#333333">TAKE 1 CAPSULE</text>`,
        `<text x="250" y="265" font-family="sans-serif" font-size="11" fill="#333333">3 TIMES DAILY BY MOUTH</text>`,
        `<text x="250" y="285" font-family="sans-serif" font-size="11" font-weight="bold" fill="#B91C1C">WITH FOOD OR WATER</text>`,
        `<text x="250" y="315" font-family="sans-serif" font-size="10" fill="#666666">QTY: 30 | EXP: 12/2027</text>`,
        `<text x="250" y="340" font-family="sans-serif" font-size="9" fill="#991B1B">FINISH ALL MEDICATION</text>`,
      ]
    ),
    mockFallback: {
      has_text: true,
      headline: "AMOXICILLIN 500 MG CAPSULES",
      full_text: "AMOXICILLIN 500 MG. TAKE 1 CAPSULE 3 TIMES DAILY BY MOUTH WITH FOOD OR WATER. QTY: 30 CAPSULES. EXP DATE: 12/2027. WARNING: FINISH ALL MEDICATION UNLESS DIRECTED BY DOCTOR.",
      text_type: "Prescription Medicine Label",
      key_details: [
        "Medication: Amoxicillin 500 mg",
        "Dosage Instruction: Take 1 capsule three times daily by mouth",
        "Special Instruction: Take with food or water",
        "Quantity: 30 capsules",
        "Expiration Date: December 2027",
        "Warning: Finish entire course of medication",
      ],
      legibility: "High - Bold clear print",
      timestamp: "12:05 PM",
      sourceType: "sample",
    },
  },
  {
    id: "transit-stairs",
    title: "Subway Station Entrance & Stairway",
    category: "transit",
    description: "Metro entrance with descending concrete stairs, bright yellow edge treads, and stainless steel handrails.",
    targetMode: "describe",
    imageUri: createSvgDataUrl(
      "Subway Entrance & Stairway",
      "Descending Stairs with Yellow Edge Warning Strips",
      ["#111827", "#030712", "#06B6D4"],
      [
        `<polygon points="120,400 240,240 400,240 520,400" fill="#374151" />`,
        `<line x1="220" y1="260" x2="420" y2="260" stroke="#FACC15" stroke-width="6" />`,
        `<line x1="200" y1="290" x2="440" y2="290" stroke="#FACC15" stroke-width="6" />`,
        `<line x1="180" y1="320" x2="460" y2="320" stroke="#FACC15" stroke-width="6" />`,
        `<line x1="160" y1="350" x2="480" y2="350" stroke="#FACC15" stroke-width="6" />`,
        `<rect x="110" y="220" width="12" height="180" fill="#94A3B8" />`,
        `<rect x="518" y="220" width="12" height="180" fill="#94A3B8" />`,
        `<text x="250" y="210" font-family="sans-serif" font-size="16" font-weight="bold" fill="#38BDF8">METRO LINE 2 ENTRANCE</text>`,
      ]
    ),
    mockFallback: {
      concise_summary: "You are approaching a subway station entrance with a flight of stairs going DOWN directly ahead, equipped with yellow edge warning strips and handrails on both sides.",
      detailed_description: "Directly ahead starting approximately 1.5 meters away is a descending staircase leading down into a transit station. There are 12 steps down. Each step tread features a high-contrast yellow tactile strip on its edge. Sturdy stainless steel handrails run along both the left and right walls.",
      spatial_layout: {
        left: "Solid tiled wall with stainless steel handrail at comfortable waist height.",
        center: "Flight of 12 descending concrete steps with yellow edge lines.",
        right: "Handrail and station transit sign reading 'Metro Line 2'.",
        ground: "Level concourse floor ending at stair tread drop-off in 1.5 meters.",
      },
      hazards_and_obstacles: [
        "Descending stairs ahead: Level change drop-off in 1.5 meters. Hold the handrail.",
        "Caution with cane on the first step downward tread.",
      ],
      lighting_condition: "Artificial transit lighting, good contrast on yellow step nosing.",
      suggested_questions: [
        "Is there an elevator or ramp alternative nearby?",
        "Are there people walking up or down right now?",
        "How many steps are in this flight?",
      ],
      timestamp: "01:20 PM",
      sourceType: "sample",
    },
  },
  {
    id: "cafe-menu",
    title: "Coffee Shop Chalkboard Menu",
    category: "menu",
    description: "Chalkboard sign listing coffee beverages, milk alternatives, bakery items, and counter order instructions.",
    targetMode: "ocr",
    imageUri: createSvgDataUrl(
      "Coffee Shop Chalkboard Menu",
      "Specialty Coffee, Bakery, & Prices",
      ["#1C1917", "#0C0A09", "#A855F7"],
      [
        `<rect x="180" y="160" width="280" height="230" rx="12" fill="#292524" stroke="#78716C" stroke-width="8" />`,
        `<text x="210" y="200" font-family="sans-serif" font-size="16" font-weight="bold" fill="#FDE047">DAILY COFFEE &amp; BAKERY</text>`,
        `<text x="210" y="235" font-family="sans-serif" font-size="13" fill="#FFFFFF">Espresso ............. $3.50</text>`,
        `<text x="210" y="260" font-family="sans-serif" font-size="13" fill="#FFFFFF">Americano ............ $4.00</text>`,
        `<text x="210" y="285" font-family="sans-serif" font-size="13" fill="#FFFFFF">Oat Flat White ....... $4.75</text>`,
        `<text x="210" y="310" font-family="sans-serif" font-size="13" fill="#FFFFFF">Butter Croissant ..... $3.50</text>`,
        `<text x="210" y="340" font-family="sans-serif" font-size="11" fill="#67E8F9">Order &amp; Pick up at Front Counter</text>`,
        `<text x="210" y="365" font-family="sans-serif" font-size="10" fill="#9CA3AF">Non-dairy milk +$0.75 | Tax incl.</text>`,
      ]
    ),
    mockFallback: {
      has_text: true,
      headline: "DAILY COFFEE & BAKERY MENU",
      full_text: "DAILY COFFEE & BAKERY. Espresso: $3.50. Americano: $4.00. Oat Flat White: $4.75. Butter Croissant: $3.50. Non-dairy milk add $0.75. All taxes included. Please order and pick up at the front counter.",
      text_type: "Restaurant / Café Menu Board",
      key_details: [
        "Espresso: $3.50",
        "Americano: $4.00",
        "Oat Flat White: $4.75",
        "Butter Croissant: $3.50",
        "Alternative Milk: Oat/Almond add $0.75",
        "Ordering: Order and collect at the front counter",
      ],
      legibility: "High - Clean chalk lettering on dark board",
      timestamp: "02:45 PM",
      sourceType: "sample",
    },
  },
];
