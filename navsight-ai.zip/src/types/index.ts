export type AppMode = 'describe' | 'ocr' | 'voice' | 'navigate' | 'history' | 'settings';

export interface SpatialLayout {
  left: string;
  center: string;
  right: string;
  ground: string;
}

export interface SceneDescriptionResult {
  concise_summary: string;
  detailed_description: string;
  spatial_layout: SpatialLayout;
  hazards_and_obstacles: string[];
  lighting_condition: string;
  suggested_questions: string[];
  timestamp: string;
  imageThumbnail?: string;
  sourceType: 'camera' | 'upload' | 'sample';
}

export interface OCRResult {
  has_text: boolean;
  headline: string;
  full_text: string;
  text_type: string;
  key_details: string[];
  legibility: string;
  timestamp: string;
  imageThumbnail?: string;
  sourceType: 'camera' | 'upload' | 'sample';
}

export interface RouteStep {
  stepNumber: number;
  instruction: string;
  name: string;
  distanceMeters: number;
  durationSeconds: number;
}

export interface NavigationResult {
  origin: { lat: number; lng: number };
  destination: {
    lat: number;
    lng: number;
    displayName: string;
  };
  distanceMeters: number;
  durationMinutes: number;
  steps: RouteStep[];
  externalLinks: {
    googleMapsWalking: string;
    openStreetMap: string;
  };
  safetyDisclaimer: string;
}

export interface HistoryItem {
  id: string;
  type: 'scene' | 'ocr' | 'voice' | 'navigation';
  title: string;
  summary: string;
  timestamp: string;
  details?: any;
  imageThumbnail?: string;
}

export interface AccessibilitySettings {
  highContrast: boolean;
  textSize: 'normal' | 'large' | 'xlarge';
  soundEffects: boolean;
  speechRate: number; // 0.8 to 1.5
  useGeminiTTS: boolean;
  reduceMotion: boolean;
  voiceGender?: string;
}

export interface SampleScenario {
  id: string;
  title: string;
  category: 'crosswalk' | 'grocery' | 'transit' | 'medicine' | 'indoor' | 'menu';
  description: string;
  imageUri: string;
  targetMode: 'describe' | 'ocr';
  mockFallback?: SceneDescriptionResult | OCRResult;
}
