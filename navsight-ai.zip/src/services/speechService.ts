import { audioFeedback } from "./audioFeedback";

export type SpeechStatus = "idle" | "speaking" | "paused";

type Listener = (status: SpeechStatus, currentText: string) => void;

class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private status: SpeechStatus = "idle";
  private currentText: string = "";
  private listeners: Set<Listener> = new Set();
  private rate: number = 1.0;
  private selectedVoice: SpeechSynthesisVoice | null = null;

  constructor() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      this.synth = window.speechSynthesis;
      // Preload voices
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => {
          this.pickBestVoice();
        };
      }
      this.pickBestVoice();
    }
  }

  private pickBestVoice(): void {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    if (!voices || voices.length === 0) return;

    // Prefer natural / high quality English voices
    const preferred = voices.find(
      (v) =>
        (v.lang.startsWith("en") && (v.name.includes("Natural") || v.name.includes("Google") || v.name.includes("Samantha") || v.name.includes("Daniel") || v.name.includes("Neural")))
    ) || voices.find((v) => v.lang.startsWith("en")) || voices[0];

    this.selectedVoice = preferred || null;
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (!this.synth) return [];
    return this.synth.getVoices();
  }

  public setVoice(voice: SpeechSynthesisVoice): void {
    this.selectedVoice = voice;
  }

  public setRate(newRate: number): void {
    this.rate = Math.max(0.5, Math.min(2.0, newRate));
    if (this.currentUtterance && this.status === "speaking") {
      // Re-trigger current text with new rate
      const text = this.currentText;
      this.speak(text);
    }
  }

  public getRate(): number {
    return this.rate;
  }

  public subscribe(cb: Listener): () => void {
    this.listeners.add(cb);
    cb(this.status, this.currentText);
    return () => this.listeners.delete(cb);
  }

  private notify(): void {
    this.listeners.forEach((cb) => cb(this.status, this.currentText));
  }

  public getStatus(): SpeechStatus {
    return this.status;
  }

  public getCurrentText(): string {
    return this.currentText;
  }

  // Stops any playing audio/speech immediately
  public stop(): void {
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement.src = "";
      this.currentAudioElement = null;
    }

    if (this.synth) {
      this.synth.cancel();
    }

    this.currentUtterance = null;
    this.status = "idle";
    this.notify();
    audioFeedback.playStopSound();
  }

  public pause(): void {
    if (this.currentAudioElement && !this.currentAudioElement.paused) {
      this.currentAudioElement.pause();
      this.status = "paused";
      this.notify();
      return;
    }

    if (this.synth && this.synth.speaking && !this.synth.paused) {
      this.synth.pause();
      this.status = "paused";
      this.notify();
    }
  }

  public resume(): void {
    if (this.currentAudioElement && this.currentAudioElement.paused) {
      this.currentAudioElement.play().catch(() => {});
      this.status = "speaking";
      this.notify();
      return;
    }

    if (this.synth && this.synth.paused) {
      this.synth.resume();
      this.status = "speaking";
      this.notify();
    }
  }

  public repeat(): void {
    if (this.currentText) {
      this.speak(this.currentText);
    }
  }

  public isSupported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  // Play studio WAV audio from Gemini TTS
  public playStudioWav(base64Wav: string, displayText: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.stop();
      this.currentText = displayText;
      this.status = "speaking";
      this.notify();

      try {
        const audio = new Audio(`data:audio/wav;base64,${base64Wav}`);
        this.currentAudioElement = audio;

        audio.onended = () => {
          this.status = "idle";
          this.currentAudioElement = null;
          this.notify();
          resolve();
        };

        audio.onerror = (e) => {
          this.status = "idle";
          this.currentAudioElement = null;
          this.notify();
          reject(e);
        };

        audio.play().catch((err) => {
          this.status = "idle";
          this.notify();
          reject(err);
        });
      } catch (err) {
        this.status = "idle";
        this.notify();
        reject(err);
      }
    });
  }

  // Speaks text using native browser speech synthesis
  public speak(text: string): Promise<void> {
    return new Promise((resolve) => {
      if (!text || text.trim() === "") {
        resolve();
        return;
      }

      // 1. Immediately cancel any prior speech to prevent overlapping audio
      this.stop();

      this.currentText = text.trim();

      if (!this.synth) {
        console.warn("SpeechSynthesis is not supported on this device/browser.");
        this.status = "idle";
        this.notify();
        resolve();
        return;
      }

      // Clean markdown asterisks or code formatting for natural voice readout
      const cleanSpoken = text
        .replace(/[*_#`~[\]]/g, "")
        .replace(/\n+/g, ". ")
        .trim();

      const utterance = new SpeechSynthesisUtterance(cleanSpoken);
      this.currentUtterance = utterance;

      if (!this.selectedVoice) {
        this.pickBestVoice();
      }
      if (this.selectedVoice) {
        utterance.voice = this.selectedVoice;
      }

      utterance.rate = this.rate;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      utterance.onstart = () => {
        this.status = "speaking";
        this.notify();
      };

      utterance.onend = () => {
        this.status = "idle";
        this.currentUtterance = null;
        this.notify();
        resolve();
      };

      utterance.onerror = (evt) => {
        // Interrupted is normal when stopped
        if (evt.error !== "interrupted" && evt.error !== "canceled") {
          console.warn("SpeechSynthesis error:", evt);
        }
        this.status = "idle";
        this.currentUtterance = null;
        this.notify();
        resolve();
      };

      // Chrome bug workaround: speechSynthesis sometimes hangs if speak isn't preceded by resume
      if (this.synth.paused) {
        this.synth.resume();
      }

      this.synth.speak(utterance);
    });
  }
}

export const speechService = new SpeechService();
