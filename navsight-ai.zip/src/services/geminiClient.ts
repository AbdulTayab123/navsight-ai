import { SceneDescriptionResult, OCRResult, NavigationResult } from "../types";

export interface ApiError {
  message: string;
  isMissingKey?: boolean;
}

export async function checkBackendHealth(): Promise<{ aiConfigured: boolean; status: string }> {
  try {
    const res = await fetch("/api/health");
    if (!res.ok) throw new Error("Health check failed");
    return await res.json();
  } catch (e) {
    return { aiConfigured: false, status: "offline" };
  }
}

export async function describeScene(
  base64Image: string,
  promptCustom?: string
): Promise<SceneDescriptionResult> {
  const response = await fetch("/api/describe-scene", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image: base64Image,
      promptCustom,
    }),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    const err: ApiError = {
      message: data.error || "Failed to analyze scene surroundings.",
      isMissingKey: data.isMissingKey,
    };
    throw err;
  }

  return {
    ...data.data,
    timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    sourceType: "camera",
  };
}

export async function readTextFromImage(base64Image: string): Promise<OCRResult> {
  const response = await fetch("/api/read-text", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image: base64Image,
    }),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    const err: ApiError = {
      message: data.error || "Failed to extract text from the image.",
      isMissingKey: data.isMissingKey,
    };
    throw err;
  }

  return {
    ...data.data,
    timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    sourceType: "camera",
  };
}

export async function askSceneQuestion(
  base64Image: string,
  question: string,
  history: Array<{ role: string; content: string }> = []
): Promise<string> {
  const response = await fetch("/api/ask-scene", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      image: base64Image,
      question,
      history,
    }),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.error || "Failed to answer question about the scene.");
  }

  return data.answer;
}

export async function fetchStudioTTS(text: string, voiceName: string = "Kore"): Promise<string> {
  const response = await fetch("/api/tts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ text, voiceName }),
  });

  const data = await response.json();

  if (!response.ok || !data.success || !data.audioBase64) {
    throw new Error(data.error || "Could not generate studio voice audio.");
  }

  return data.audioBase64;
}

export async function fetchWalkingRoute(
  originLat: number,
  originLng: number,
  destinationQuery: string
): Promise<NavigationResult> {
  const response = await fetch("/api/navigation-route", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      originLat,
      originLng,
      destinationQuery,
    }),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.error || "Could not calculate walking navigation route.");
  }

  return data;
}
